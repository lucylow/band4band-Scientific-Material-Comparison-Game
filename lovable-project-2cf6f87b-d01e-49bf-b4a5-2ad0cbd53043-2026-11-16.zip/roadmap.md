# Uploaded app import
- [x] Preserve Band for Band design, catalog, 100 module pages, 400 validation tools, and demo APIs.
- [x] Verify imported tests and desktop/mobile workflows.
- [x] Save the imported app; leave publishing to the user.

# Expansion 05 improvements
- [ ] Complete the four scientific trust calculations and preserve their API contracts.
- [ ] Add readable results and optional uncertainty inputs to the existing trust lab.
- [ ] Verify tests, desktop/mobile analysis and exports; save changes.
- [ ] Historical v2/v3 router references: blocked by absent backend modules in the expansion archive.
