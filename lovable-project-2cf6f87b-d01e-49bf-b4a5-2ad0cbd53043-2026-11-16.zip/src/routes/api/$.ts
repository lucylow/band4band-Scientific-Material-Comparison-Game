import { createFileRoute } from "@tanstack/react-router";
import { handleMaterialApi } from "@/lib/material-api";
// Legacy source URLs remain valid; external callers can use /api/public/* after publish.
export const Route=createFileRoute('/api/$')({server:{handlers:{
  GET:({request})=>handleMaterialApi(request),
  POST:({request})=>handleMaterialApi(request),
}}});