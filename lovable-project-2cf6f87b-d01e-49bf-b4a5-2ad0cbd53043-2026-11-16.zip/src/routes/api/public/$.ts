import { createFileRoute } from "@tanstack/react-router";
import { handleMaterialApi } from "@/lib/material-api";
export const Route=createFileRoute('/api/public/$')({server:{handlers:{
  GET:({request})=>handleMaterialApi(request),
  POST:({request})=>handleMaterialApi(request),
}}});