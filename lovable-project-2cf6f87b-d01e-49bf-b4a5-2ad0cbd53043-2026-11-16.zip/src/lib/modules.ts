import { screens } from "@/data/screens";
export function moduleSlug(id:number) { const screen=screens.find(s=>s.id===id); return screen ? `${String(id).padStart(3,"0")}-${screen.title.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/-$/,"")}` : "001-welcome-landing"; }
export function getModule(slug:string) { return screens.find(s=>moduleSlug(s.id)===slug); }
