import { z } from "zod";
import {evaluateQualityApi} from "./expansion/quality-api";
import { materials } from "@/data/materials";
import { compare } from "@/lib/scoring";

// Preserve the original API's three-material fixture, separate from the six-item UI catalog.
const demo = materials.slice(0,3).map(m=>({...m,crystal:m.id==='gan-demo'?'Wurtzite':m.crystal}));
function record(m:typeof materials[number]) {
  return {id:m.id,name:m.name,formula:m.formula,family:m.family,crystal:m.crystal,
    properties:Object.fromEntries(m.properties.filter(p=>['band_gap','density','thermal_conductivity','mobility'].includes(p.key)).map(p=>[p.key,{value:p.value,unit:p.unit,evidence:p.evidence,source:p.evidence==='Unavailable'?null:p.source}]))};
}
const id=z.string().min(1).max(100);
const weight=z.number().finite().min(0).max(1);
const comparison=z.object({material_a:id,material_b:id,
  weights:z.record(weight).refine(v=>Object.keys(v).length>0&&Object.keys(v).length<=20).default({band_gap:.4,thermal_conductivity:.25,density:.2,mobility:.15}),
  directions:z.record(z.enum(['high','low'])).default({band_gap:'high',thermal_conductivity:'high',density:'low',mobility:'high'})});
const battle=z.object({player_id:id.default('demo-player'),material_a:id,material_b:id,profile:id.default('power')});
const json=(data:unknown,status=200)=>Response.json(data,{status});

export async function handleMaterialApi(request:Request):Promise<Response>{
  const url=new URL(request.url);const path=url.pathname.replace(/^\/api\/public\//,'/api/');
  if(request.method==='GET'){
    if(path==='/api/health')return json({status:'ok',mode:'demo',timestamp:Math.floor(Date.now()/1000)});
    if(path==='/api/sources')return json({policy:'Every property should carry a source, unit, evidence type, method/conditions when available, and retrieval timestamp.',evidence_types:['Experimental','Computational','Derived','Estimated','Unavailable'],materials_project_key_configured:false});
    if(path==='/api/materials/search'){
      const parsed=z.string().max(100).safeParse(url.searchParams.get('q')??'');
      if(!parsed.success)return json({detail:'Search must be at most 100 characters'},422);
      const q=parsed.data.toLowerCase();return json(demo.filter(m=>(m.name+m.formula+m.family).toLowerCase().includes(q)).map(record));
    }
    const match=path.match(/^\/api\/materials\/([^/]+)(\/structure)?$/);
    if(match?.[1]){const materialId=decodeURIComponent(match[1]);const material=demo.find(m=>m.id===materialId);if(!material)return json({detail:'Material not found in local demo cache. No live scientific adapter is configured.'},404);
      if(match[2])return json({material_id:material.id,status:'not_cached',message:'No crystal coordinates are fabricated in demo mode. A live scientific adapter is not configured.'});
      return json(record(material));}
  }
  if(request.method==='POST'){
    let body:unknown;try{body=await request.json();}catch{return json({detail:'Invalid JSON'},400);}
    if(path.startsWith('/api/v4/')){
      try {const result=evaluateQualityApi(path,body);return result===undefined?json({detail:'Endpoint not found'},404):json(result);}
      catch(error){return json({detail:error instanceof z.ZodError?error.issues.map(i=>i.message).join('; '):error instanceof Error?error.message:'Invalid input'},422);}
    }
    if(path==='/api/compare'){
      const parsed=comparison.safeParse(body);if(!parsed.success)return json({detail:'Invalid comparison request'},422);
      const req=parsed.data,a=demo.find(m=>m.id===req.material_a),b=demo.find(m=>m.id===req.material_b);
      if(!a||!b)return json({detail:'Both materials must exist in the local demo cache'},404);
      const result=compare(a,b,{name:'API profile',weights:req.weights,directions:req.directions});
      const ar=record(a),br=record(b);
      return json({material_a:a.id,material_b:b.id,score_a:result.scoreA,score_b:result.scoreB,evidence_coverage:result.coverage,winner:result.winner,
        rows:result.rows.map(r=>({property:r.key,a:ar.properties[r.key]??{value:null},b:br.properties[r.key]??{value:null},weight:r.weight,winner:r.winner}))});
    }
    if(path==='/api/battles'){
      const parsed=battle.safeParse(body);if(!parsed.success)return json({detail:'Invalid battle request'},422);
      if(parsed.data.material_a===parsed.data.material_b)return json({detail:'Choose two different materials'},400);
      return json({battle_id:`demo-${Math.floor(Date.now()/1000)}`,...parsed.data,status:'created',mode:'demo'});
    }
  }
  return json({detail:'Endpoint not found'},404);
}