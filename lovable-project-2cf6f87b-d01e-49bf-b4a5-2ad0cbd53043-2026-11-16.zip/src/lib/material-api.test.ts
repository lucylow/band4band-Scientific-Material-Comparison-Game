import { describe,it,expect } from 'vitest';
import { handleMaterialApi } from './material-api';
const call=(path:string,body?:unknown)=>handleMaterialApi(new Request(`http://localhost/api/public/${path}`,body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:undefined));
describe('migrated demo API',()=>{
  it('reports demo health',async()=>{expect((await (await call('health')).json()).mode).toBe('demo')});
  it('searches Silicon',async()=>{expect((await (await call('materials/search?q=silicon')).json())[0].formula).toBe('Si')});
  it('does not invent missing materials',async()=>{expect((await call('materials/unknown')).status).toBe(404)});
  it('excludes missing mobility and reports concrete coverage',async()=>{const r=await (await call('compare',{material_a:'mp-149',material_b:'gan-demo'})).json();expect(r.evidence_coverage).toBe(85);expect(r.rows.find((v:{property:string})=>v.property==='mobility').winner).toBe('N/A');expect(r.score_a).toBe(53);expect(r.score_b).toBe(47)});
  it('rejects same-material battles',async()=>{expect((await call('battles',{material_a:'mp-149',material_b:'mp-149'})).status).toBe(400)});
  it('does not fabricate structure coordinates',async()=>{const r=await (await call('materials/mp-149/structure')).json();expect(r.status).toBe('not_cached');expect(r).not.toHaveProperty('coordinates')});
});