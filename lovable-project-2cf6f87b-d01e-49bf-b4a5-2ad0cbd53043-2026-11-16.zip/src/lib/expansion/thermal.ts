/** Explicit 1-D transient heat diffusion demo using a stable FTCS step. */
export type ThermalInput = { conductivity:number; density:number; heatCapacity:number; length:number; nodes:number; durationSeconds:number; initialC:number; leftBoundaryC:number; rightBoundaryC:number };
export type ThermalResult = { time:number; temperatures:number[]; alpha:number; stableStepSeconds:number; steps:number };
export function simulate1DHeat(input: ThermalInput): ThermalResult {
  const {conductivity:k,density:rho,heatCapacity:cp,length,nodes,durationSeconds}=input;
  if ([k,rho,cp,length,durationSeconds].some(x=>!Number.isFinite(x)||x<=0) || !Number.isInteger(nodes) || nodes<3 || nodes>300 || [input.initialC,input.leftBoundaryC,input.rightBoundaryC].some(x=>!Number.isFinite(x))) throw new Error('Use positive physical inputs and 3–300 nodes.');
  const dx=length/(nodes-1), alpha=k/(rho*cp), dtMax=0.45*dx*dx/(2*alpha), steps=Math.max(1,Math.ceil(durationSeconds/dtMax)),dt=durationSeconds/steps;
  if(steps>100000) throw new Error('Simulation requires too many steps. Reduce conductivity or duration.');
  let t=Array.from({length:nodes},()=>input.initialC); t[0]=input.leftBoundaryC;t[nodes-1]=input.rightBoundaryC;
  const r=alpha*dt/(dx*dx);
  for(let n=0;n<steps;n++){const next=[...t];for(let i=1;i<nodes-1;i++){const center=t[i],left=t[i-1],right=t[i+1];if(center===undefined||left===undefined||right===undefined)throw new Error('Invalid thermal grid');next[i]=center+r*(left-2*center+right)};t=next;}
  return {time:durationSeconds,temperatures:t,alpha,stableStepSeconds:dt,steps};
}
