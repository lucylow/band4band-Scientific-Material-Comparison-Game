import { Matrix, solve } from 'ml-matrix';
export function parseList(raw: string) {
  const parts = raw.split(',');
  if (parts.some(value => !value.trim() || !Number.isFinite(Number(value)))) throw new Error('Every sample must be a finite number; blank samples are not zero.');
  return parts.map(value => Number(value.trim()));
}
function fit(x: number[], y: number[], degree: number) {
  if (x.length !== y.length || x.length < 3 || [...x, ...y].some(value => !Number.isFinite(value))) throw new Error('Enter at least three paired finite samples.');
  if (new Set(x).size < degree + 1) throw new Error('Use more distinct independent samples.');
  const design = new Matrix(x.map(value => Array.from({ length: degree + 1 }, (_, index) => value ** index)));
  const coefficients = solve(design, Matrix.columnVector(y), true).to1DArray();
  const mean = y.reduce((a, b) => a + b, 0) / y.length;
  const prediction = x.map(value => coefficients.reduce((sum, coefficient, index) => sum + coefficient * value ** index, 0));
  const residual = y.reduce((sum, value, index) => sum + (value - (prediction[index] ?? NaN)) ** 2, 0);
  const total = y.reduce((sum, value) => sum + (value - mean) ** 2, 0);
  return { coefficients, r2: total === 0 ? (residual < 1e-20 ? 1 : 0) : 1 - residual / total };
}
export function fitLine(x: number[], y: number[]) {
  const result = fit(x, y, 1);
  const [intercept, slope] = result.coefficients;
  if (intercept === undefined || slope === undefined) throw new Error('Fit failed.');
  return { intercept, slope, r2: result.r2 };
}
export function fitQuadratic(x: number[], y: number[]) {
  const result = fit(x, y, 2);
  const [c, b, a] = result.coefficients;
  if (a === undefined || b === undefined || c === undefined || a <= 0) throw new Error('This tool expects a positive-curvature conduction-band minimum.');
  return { a, b, c, mass: 3.80998211615486 / a, r2: result.r2 };
}