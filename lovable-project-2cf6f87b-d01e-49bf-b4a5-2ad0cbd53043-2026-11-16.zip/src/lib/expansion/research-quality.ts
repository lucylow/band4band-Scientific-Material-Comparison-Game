import { z } from 'zod';
const finite=z.number().finite();
const recordSchema=z.object({value:finite.nullable().optional(),unit:z.string().max(500).optional(),evidence_type:z.enum(['Experimental','Computational','Derived','Estimated','Unavailable']).optional(),source:z.string().max(10000).optional(),method:z.string().max(10000).optional(),conditions:z.string().max(10000).optional(),retrieved_at:z.string().max(500).optional()});
export function auditRecord(input:unknown){const record=recordSchema.parse(input),required=['value','unit','evidence_type','source','method','conditions','retrieved_at'] as const;
 if(record.evidence_type==='Unavailable'&&record.value!=null)throw new Error('Unavailable evidence must not carry a numeric value.');
 const missing:string[]=required.filter(k=>record[k]==null||record[k]==='');if(record.value==null&&record.evidence_type&&record.evidence_type!=='Unavailable')missing.push('numeric_value');
 const warnings:string[]=[];if(record.evidence_type==='Computational'&&!record.method)warnings.push('Computational result has no method metadata.');if(record.evidence_type==='Experimental'&&!record.conditions)warnings.push('Experimental result has no measurement conditions.');
 return {completeness_percent:Math.round(100*(required.length-missing.filter(k=>required.some(r=>r===k)).length)/required.length),missing_fields:missing,warnings,status:missing.length||warnings.length?'incomplete':'complete',required_fields:[...required],policy:'Completeness is not source authenticity or scientific validity.'};
}
export function compareValues(experimental:number,calculated:number,tolerance:number,experimentalUncertainty?:number,calculatedUncertainty?:number){
 finite.parse(experimental);finite.parse(calculated);finite.min(0).max(10000).parse(tolerance);
 if(experimentalUncertainty!==undefined)finite.nonnegative().parse(experimentalUncertainty);
 if(calculatedUncertainty!==undefined)finite.nonnegative().parse(calculatedUncertainty);
 if(experimental===0)throw new Error('Percent deviation is undefined for a zero experimental value.');
 const difference=Math.abs(calculated-experimental),deviation=difference/Math.abs(experimental)*100;
 const combined=experimentalUncertainty!==undefined&&calculatedUncertainty!==undefined?Math.hypot(experimentalUncertainty,calculatedUncertainty):null;
 const normalized=combined===null?null:combined===0?(difference===0?0:null):difference/combined;
 if(!Number.isFinite(difference)||!Number.isFinite(deviation)||(combined!==null&&!Number.isFinite(combined)))throw new Error('Input magnitudes exceed the numerical range.');
 return {experimental,calculated,absolute_difference:difference,absolute_percent_deviation:deviation,tolerance_percent:tolerance,within_tolerance:deviation<=tolerance,combined_standard_uncertainty:combined,normalized_difference_z:normalized,interpretation:deviation<=tolerance?'Agreement within the chosen percent tolerance is a screening result, not proof of model validity.':'Difference exceeds the selected tolerance; inspect phase, conditions, method and units.'};
}
const term=z.object({value:finite,uncertainty:finite.nonnegative(),label:z.string().max(200).optional()});
export function propagateProduct(input:unknown,relative=false){
 const terms=z.array(term).min(1).max(50).parse(input);
 if(relative&&terms.some(t=>t.value===0))throw new Error('Relative propagation is undefined for zero-valued factors.');
 const value=terms.reduce((p,t)=>p*t.value,1);
 const variance=terms.reduce((sum,t,i)=>sum+(t.uncertainty*terms.reduce((p,other,j)=>p*(i===j?1:other.value),1))**2,0);
 const standard=relative?Math.abs(value)*Math.sqrt(terms.reduce((sum,t)=>sum+(t.uncertainty/t.value)**2,0)):Math.sqrt(variance);
 if(!Number.isFinite(value)||!Number.isFinite(standard)||!Number.isFinite(2*standard))throw new Error('Input magnitudes exceed the numerical range.');
 return {operation:'product',value,combined_standard_uncertainty:standard,expanded_uncertainty_k2:2*standard,coverage_factor:2,assumption:'First-order independent-input propagation; covariance is not included.',inputs:terms.map((t,i)=>({label:t.label??`Input ${i+1}`,value:t.value,standard_uncertainty:t.uncertainty}))};
}
export function weightedMean(input:unknown){const terms=z.array(term.extend({uncertainty:finite.positive()})).min(2).max(100).parse(input),weights=terms.map(t=>1/t.uncertainty**2),sum=weights.reduce((a,b)=>a+b,0),mean=terms.reduce((n,t,i)=>n+t.value*(weights[i]??0),0)/sum;const chi=terms.reduce((n,t,i)=>n+(weights[i]??0)*(t.value-mean)**2,0);if(!Number.isFinite(sum)||!Number.isFinite(mean)||!Number.isFinite(chi)||sum<=0)throw new Error('Uncertainty magnitudes exceed the numerical range.');return {weighted_mean:mean,standard_uncertainty:Math.sqrt(1/sum),chi_squared:chi,degrees_of_freedom:terms.length-1,assumption:'Independent measurements with positive standard uncertainties; investigate excess scatter before pooling.'};}
