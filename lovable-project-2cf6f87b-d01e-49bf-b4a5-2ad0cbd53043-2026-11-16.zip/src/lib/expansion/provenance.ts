import type { PropertyRecord } from '../../data/materials';
export type EvidenceAudit = { complete: boolean; issues: string[]; score: number };
export function auditEvidence(record: Partial<PropertyRecord>): EvidenceAudit {
  const issues: string[] = [];
  if (!record.unit) issues.push('Missing unit');
  if (!record.evidence) issues.push('Missing evidence classification');
  if (record.value === null && record.evidence !== 'Unavailable') issues.push('Missing value is not labelled unavailable');
  if (record.value !== null && !record.source) issues.push('Missing source attribution');
  if (record.evidence === 'Computational' && !record.method) issues.push('Computational method not recorded');
  return { complete: issues.length === 0, issues, score: Math.round(100 * (5 - issues.length) / 5) };
}
export function evidenceLabel(evidence: PropertyRecord['evidence']): string {
  return ({ Experimental:'Measured', Computational:'Calculated', Derived:'Derived', Estimated:'Estimated', Unavailable:'Unavailable' })[evidence];
}
