import { z } from 'zod';
const finite = z.number().finite();
const bandSchema = z.object({title:z.string().max(160).optional(),source_label:z.string().max(300).optional(),fermi_level_ev:finite,kpoints:z.array(z.tuple([finite,finite,finite])).min(2).max(10000),energies_by_kpoint:z.array(z.array(finite).min(2).max(500)).min(2).max(10000)});
export function analyzeBands(input:unknown) {
 const data=bandSchema.parse(input),rows=data.energies_by_kpoint,width=rows[0]?.length;
 if(data.kpoints.length!==rows.length || rows.some(row=>row.length!==width)) throw new Error('Provide one equally sized band-energy row per k-point.');
 let vbm=-Infinity,cbm=Infinity,direct=Infinity;
 const counts:number[]=[];
 rows.forEach(row=>{const occupied=row.filter(v=>v<=data.fermi_level_ev),empty=row.filter(v=>v>data.fermi_level_ev);counts.push(occupied.length);if(!occupied.length||!empty.length)return;const vb=Math.max(...occupied),cb=Math.min(...empty);vbm=Math.max(vbm,vb);cbm=Math.min(cbm,cb);direct=Math.min(direct,cb-vb);});
 if(!Number.isFinite(vbm)||!Number.isFinite(cbm))throw new Error('The Fermi level must split occupied and unoccupied states at a sampled k-point.');
 return {...data,title:data.title??'Uploaded band structure',source_label:data.source_label??'User-supplied data',kpoint_count:rows.length,band_count:width,fundamental_gap_ev:Math.max(0,cbm-vbm),direct_gap_minimum_on_sampled_path_ev:direct,valence_band_maximum_ev:vbm,conduction_band_minimum_ev:cbm,occupied_band_count_by_kpoint:counts,interpretation_limits:['Supplied k-point path only; no interpolation or full Brillouin-zone search.','Fermi-level partition only; spin, smearing and occupations are not inferred.','A sampled-path gap is not proof of a global fundamental gap.']};
}
type Vector=[number,number,number];
const numeric=(raw:string)=>{if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?(?:\(\d+\))?$/.test(raw))throw new Error(`Invalid numeric CIF value: ${raw}`);const value=Number(raw.replace(/\(\d+\)$/,''));if(!Number.isFinite(value))throw new Error('CIF values must be finite.');return value;};
function tokens(line:string){return (line.match(/'(?:[^']*)'|"(?:[^"]*)"|[^\s]+/g)??[]).map(t=>t.replace(/^['"]|['"]$/g,''));}
export function inspectCif(text:string,cutoff:number){
 if(!text.trim()||text.length>2000000)throw new Error('Provide CIF text within the 2 MB limit.');
 if(!Number.isFinite(cutoff)||cutoff<.1||cutoff>12)throw new Error('Pair-distance cutoff must be between 0.1 and 12 Å.');
 const scalars:Record<string,string>={},atoms:{label:string;element:string;fractional:Vector;cartesian_angstrom:Vector}[]=[];
 const lines=text.split(/\r?\n/);let i=0;
 while(i<lines.length){const line=(lines[i]??'').trim();if(!line||line.startsWith('#')){i++;continue;}
  if(line.toLowerCase()==='loop_'){i++;const headers:string[]=[];while((lines[i]??'').trim().startsWith('_')){headers.push(tokens((lines[i]??'').trim())[0]??'');i++;}
   const values:string[]=[];while(i<lines.length){const raw=(lines[i]??'').trim();if(raw.toLowerCase()==='loop_'||raw.startsWith('_')||raw.toLowerCase().startsWith('data_'))break;if(raw&&!raw.startsWith('#'))values.push(...tokens(raw.split(/\s+#/)[0]??''));i++;}
   const keys=['_atom_site_fract_x','_atom_site_fract_y','_atom_site_fract_z'];if(keys.every(k=>headers.includes(k))){if(values.length%headers.length)throw new Error('Atom-site loop contains an incomplete row.');
    for(let off=0;off<values.length;off+=headers.length){const row=values.slice(off,off+headers.length),get=(key:string)=>row[headers.indexOf(key)];const label=get('_atom_site_label')??get('_atom_site_type_symbol')??`site-${atoms.length+1}`,element=(get('_atom_site_type_symbol')??label).match(/^[A-Z][a-z]?/)?.[0];if(!element)throw new Error(`Cannot determine element for ${label}.`);const coords=keys.map(k=>numeric(get(k)??''));atoms.push({label,element,fractional:[coords[0]??0,coords[1]??0,coords[2]??0],cartesian_angstrom:[0,0,0]});}
   }continue;}
  if(line.startsWith('_')){const [key,value]=tokens(line);if(key&&value)scalars[key]=value;}i++;
 }
 const required=['_cell_length_a','_cell_length_b','_cell_length_c','_cell_angle_alpha','_cell_angle_beta','_cell_angle_gamma'];const missing=required.filter(k=>scalars[k]===undefined);if(missing.length)throw new Error(`Missing cell fields: ${missing.join(', ')}`);
 const values=required.map(k=>numeric(scalars[k]??''));const [a=0,b=0,c=0,alpha=0,beta=0,gamma=0]=values;
 if(Math.min(a,b,c)<=0||[alpha,beta,gamma].some(v=>v<=0||v>=180))throw new Error('Cell lengths must be positive; angles must be between 0 and 180 degrees.');
 const [al=0,be=0,ga=0]=[alpha,beta,gamma].map(v=>v*Math.PI/180),cx=c*Math.cos(be),cy=c*(Math.cos(al)-Math.cos(be)*Math.cos(ga))/Math.sin(ga),cz2=c*c-cx*cx-cy*cy;
 if(cz2<=1e-12)throw new Error('Invalid or degenerate cell metric.');
 const vectors:Vector[]=[[a,0,0],[b*Math.cos(ga),b*Math.sin(ga),0],[cx,cy,Math.sqrt(cz2)]];
 const cart=(frac:Vector):Vector=>[0,1,2].map(j=>frac.reduce((sum,v,k)=>sum+v*(vectors[k]?.[j]??0),0)) as Vector;
 if(!atoms.length)throw new Error('No explicit fractional atom-site loop found.');
 // Keep browser work bounded; large structures should use a dedicated scientific service.
 if(atoms.length>500)throw new Error('This browser inspector supports up to 500 explicit sites.');
 atoms.forEach(atom=>{atom.cartesian_angstrom=cart(atom.fractional);});
 const pairs:{site_i:number;site_j:number;distance_angstrom:number}[]=[];
 atoms.forEach((first,idx)=>{for(let j=idx+1;j<atoms.length;j++){const other=atoms[j];if(!other)continue;const delta=first.fractional.map((v,k)=>(other.fractional[k]??0)-v);let best=Infinity;for(let x=-1;x<=1;x++)for(let y=-1;y<=1;y++)for(let z=-1;z<=1;z++){const d=cart([(delta[0]??0)+x,(delta[1]??0)+y,(delta[2]??0)+z]);best=Math.min(best,Math.hypot(...d));}if(best<=cutoff)pairs.push({site_i:idx,site_j:j,distance_angstrom:Number(best.toFixed(6))});}});
 return {cell:{a,b,c,alpha,beta,gamma,volume_angstrom3:Number((a*b*Math.sin(ga)*Math.sqrt(cz2)).toFixed(8))},site_count_explicit:atoms.length,sites:atoms,pairs_within_cutoff:pairs,symmetry_expanded:false,limitations:['Explicit sites only; symmetry is not expanded.','No occupancy normalization or disorder resolution.','Nearest images use a 3×3×3 neighboring-cell search; extreme skew cells require a full crystallographic tool.']};
}
