import { describe, expect, it } from 'vitest';
import { bandgapToWavelengthNm, thermalDiffusivityM2S } from './physics';
import { simulate1DHeat } from './thermal';
import { fitQuadratic, parseList } from './fitting';
import { gradeLocalMission } from './missions';
import { FEATURE_MODULES } from '@/expansion/registry';
describe('Scientific workbench', () => {
  it('calculates the 3.4 eV photon edge', () => expect(bandgapToWavelengthNm(3.4)).toBeCloseTo(364.6594, 4));
  it('keeps missing and zero bandgaps unavailable', () => { expect(bandgapToWavelengthNm(null)).toBeNull(); expect(bandgapToWavelengthNm(0)).toBeNull(); });
  it('calculates diffusivity from all three inputs', () => expect(thermalDiffusivityM2S(130, 6150, 490)).toBeCloseTo(0.0000431392, 9));
  it('rejects incomplete fit samples', () => expect(() => parseList('1,,3')).toThrow());
  it('fits the supplied parabolic band', () => expect(fitQuadratic([-.2,-.1,0,.1,.2],[1.08,1.02,1,1.02,1.08]).mass).toBeCloseTo(1.904991, 5));
  it('does not reward negated mission answers', () => expect(gradeLocalMission('missing-not-zero','not no')?.correct).toBe(false));
  it('exposes 400 distinct validation tools', () => expect(new Set(FEATURE_MODULES.map(module => module.id)).size).toBe(400));
  it('bounds expensive simulations', () => expect(() => simulate1DHeat({ conductivity:1e12,density:1,heatCapacity:1,length:.01,nodes:9,durationSeconds:2,initialC:25,leftBoundaryC:100,rightBoundaryC:25 })).toThrow());
});