import {describe,it,expect} from 'vitest';
import {inspectCif,analyzeBands} from './research-ingestion';
import {auditRecord,compareValues,propagateProduct,weightedMean} from './research-quality';
import {FEATURE_MODULES} from '@/expansion/registry';
const cif=`data_test
_cell_length_a 5.43(2)
_cell_length_b 5.43
_cell_length_c 5.43
_cell_angle_alpha 90
_cell_angle_beta 90
_cell_angle_gamma 90
loop_
_atom_site_label
_atom_site_type_symbol
_atom_site_fract_x
_atom_site_fract_y
_atom_site_fract_z
Si1 Si 0 0 0
Si2 Si .25 .25 .25`;
describe('Uploaded research-data workflows',()=>{
 it('inspects explicit CIF geometry without expanding symmetry',()=>{const r=inspectCif(cif,3);expect(r.site_count_explicit).toBe(2);expect(r.symmetry_expanded).toBe(false);expect(r.cell.volume_angstrom3).toBeCloseTo(160.103007,6);expect(r.pairs_within_cutoff[0]?.distance_angstrom).toBeCloseTo(2.351259,6);});
 it('rejects missing CIF metrics',()=>expect(()=>inspectCif(cif.replace('_cell_angle_gamma 90',''),3)).toThrow('Missing cell'));
 it('bounds browser pair calculations to 500 sites',()=>expect(()=>inspectCif(cif+'\n'+Array.from({length:499},(_,i)=>`Si${i+3} Si 0 0 0`).join('\n'),3)).toThrow('500 explicit sites'));
 it('calculates a sampled band gap and direct gap',()=>{const r=analyzeBands({fermi_level_ev:0,kpoints:[[0,0,0],[.5,0,0],[1,0,0]],energies_by_kpoint:[[-1,1],[-.8,1.2],[-1.1,.9]]});expect(r.fundamental_gap_ev).toBeCloseTo(1.7);expect(r.direct_gap_minimum_on_sampled_path_ev).toBeCloseTo(2);});
 it('rejects ragged band rows and non-finite energies',()=>{expect(()=>analyzeBands({fermi_level_ev:0,kpoints:[[0,0,0],[1,0,0]],energies_by_kpoint:[[-1,1],[-1,1,2]]})).toThrow();expect(()=>analyzeBands({fermi_level_ev:0,kpoints:[[0,0,0],[1,0,0]],energies_by_kpoint:[[-1,Infinity],[-1,1]]})).toThrow();});
 it('keeps unavailable evidence free of numeric values',()=>expect(()=>auditRecord({value:1,evidence_type:'Unavailable'})).toThrow());
 it('audits all seven evidence fields',()=>expect(auditRecord({value:1,unit:'eV',evidence_type:'Experimental',source:'source',method:'absorption',conditions:'300 K',retrieved_at:'2026-11-15'}).completeness_percent).toBe(100));
 it('uses an explicit percent tolerance',()=>{expect(compareValues(100,110,10).within_tolerance).toBe(true);expect(compareValues(100,111,10).within_tolerance).toBe(false);expect(()=>compareValues(0,1,10)).toThrow();});
 it('propagates independent product uncertainties',()=>{const r=propagateProduct([{value:2,uncertainty:.1},{value:3,uncertainty:.2}]);expect(r.value).toBe(6);expect(r.combined_standard_uncertainty).toBeCloseTo(.5);expect(r.expanded_uncertainty_k2).toBe(1);});
 it('handles zero product factors without dividing by zero',()=>expect(propagateProduct([{value:0,uncertainty:.1},{value:3,uncertainty:.2}]).combined_standard_uncertainty).toBeCloseTo(.3));
 it('pools independent measurements by inverse variance',()=>{const r=weightedMean([{value:1.1,uncertainty:.1},{value:1.2,uncertainty:.2}]);expect(r.weighted_mean).toBeCloseTo(1.12);expect(r.standard_uncertainty).toBeCloseTo(Math.sqrt(1/125));expect(()=>weightedMean([{value:1,uncertainty:0},{value:2,uncertainty:1}])).toThrow();});
 it('includes both new module tranches with their own screening rules',()=>{expect(FEATURE_MODULES.find(m=>m.id===301)).toBeDefined();expect(FEATURE_MODULES.find(m=>m.id===499)).toBeDefined();expect(FEATURE_MODULES.find(m=>m.id===406)?.evaluate(-.1)).toMatchObject({status:'fail'});});
});
