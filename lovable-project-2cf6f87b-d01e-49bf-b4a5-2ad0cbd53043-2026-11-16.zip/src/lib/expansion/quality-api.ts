import {z} from 'zod';
import {auditRecord,compareValues,propagateProduct,weightedMean} from './research-quality';
const finite=z.number().finite();
const product=z.object({inputs:z.array(z.object({value:finite,uncertainty:finite.nonnegative(),label:z.string().max(200).optional()})).min(1).max(50),relative:z.boolean().default(false)});
const mean=z.object({values:z.array(finite).min(2).max(100),uncertainties:z.array(finite.positive()).min(2).max(100)}).refine(r=>r.values.length===r.uncertainties.length,'Provide one uncertainty per value.');
const comparison=z.object({experimental:finite,calculated:finite,tolerance_percent:finite.min(0).max(10000).default(10),experimental_uncertainty:finite.nonnegative().optional(),calculated_uncertainty:finite.nonnegative().optional()});
export function evaluateQualityApi(path:string,body:unknown){
 if(path==='/api/v4/uncertainty/product'){const r=product.parse(body);return propagateProduct(r.inputs,r.relative);}
 if(path==='/api/v4/uncertainty/weighted-mean'){const r=mean.parse(body);return weightedMean(r.values.map((value,i)=>({value,uncertainty:r.uncertainties[i]})));}
 if(path==='/api/v4/provenance/audit')return auditRecord(z.object({record:z.record(z.unknown())}).parse(body).record);
 if(path==='/api/v4/validation/compare'){const r=comparison.parse(body);return compareValues(r.experimental,r.calculated,r.tolerance_percent,r.experimental_uncertainty,r.calculated_uncertainty);}
 return undefined;
}
