/** Transparent derived quantities. Outputs are explicitly labelled as calculations. */
export const HC_EV_NM = 1239.841984;
export function bandgapToWavelengthNm(gapEv: number | null): number | null {
  if (gapEv === null || !Number.isFinite(gapEv) || gapEv <= 0) return null;
  return HC_EV_NM / gapEv;
}
export function thermalDiffusivityM2S(kWmK: number, densityKgM3: number, cpJkgK: number): number | null {
  if ([kWmK,densityKgM3,cpJkgK].some(v => !Number.isFinite(v) || v <= 0)) return null;
  return kWmK / (densityKgM3 * cpJkgK);
}
export function electronVoltToJoule(ev: number): number { return ev * 1.602176634e-19; }
export function validatePhysicalValue(value: number | null, unit: string): string[] {
  const issues: string[] = [];
  if (value !== null && !Number.isFinite(value)) issues.push('Value must be finite.');
  if (!unit.trim()) issues.push('A unit is required.');
  return issues;
}
