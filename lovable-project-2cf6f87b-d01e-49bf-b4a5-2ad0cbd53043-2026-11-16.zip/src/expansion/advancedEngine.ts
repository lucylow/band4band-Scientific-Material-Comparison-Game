import type {FeatureResult} from './featureEngine';
export type AdvancedRule='nonnegative'|'positive'|'signed'|'percent'|'fraction'|'angle'|'integer'|'positive_integer';
export function evaluateAdvancedMetric(rule:string,value:number|null):FeatureResult{
 if(value===null||!Number.isFinite(value))return {status:'missing',message:'No finite value supplied. The module will not infer or impute one.',value:null};
 let pass=false;
 switch(rule){
  case 'nonnegative':pass=value>=0;break;
  case 'positive':pass=value>0;break;
  case 'signed':pass=true;break;
  case 'percent':pass=value>=0&&value<=100;break;
  case 'fraction':pass=value>=0&&value<=1;break;
  case 'angle':pass=value>=0&&value<=180;break;
  case 'integer':pass=Number.isInteger(value);break;
  case 'positive_integer':pass=Number.isInteger(value)&&value>0;break;
  default:pass=false;
 }
 return {status:pass?'pass':'fail',message:pass?'Input passes the selected screening rule.':'Input fails the screening rule. Check the unit, scale and measurement context.',value};
}
