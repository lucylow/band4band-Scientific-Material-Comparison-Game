import {evaluateFeature} from '../featureEngine';
export const module={id:196,slug:'source-date-check',title:'Source date metadata',metric:'source_year',unit:'year',rule:'year',description:'Checks a plausible source publication year.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
