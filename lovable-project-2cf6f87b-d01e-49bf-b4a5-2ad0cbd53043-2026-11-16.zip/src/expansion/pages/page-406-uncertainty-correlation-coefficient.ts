import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:406,slug:'uncertainty-correlation-coefficient',title:'Uncertainty Correlation Coefficient',metric:'uncertainty_correlation_coefficient',unit:'—',rule:'fraction',description:'Checks uncertainty correlation coefficient for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
