import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:205,slug:'electronic-thermal-conductivity',title:'Electronic thermal conductivity',metric:'electronic_kappa',unit:'W/(m·K)',rule:'nonnegative',description:'Screens electronic thermal conductivity values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
