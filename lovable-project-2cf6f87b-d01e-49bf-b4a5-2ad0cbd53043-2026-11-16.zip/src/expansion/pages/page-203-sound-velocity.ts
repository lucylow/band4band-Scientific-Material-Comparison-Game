import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:203,slug:'sound-velocity',title:'Sound velocity',metric:'sound_velocity',unit:'m/s',rule:'positive',description:'Screens sound velocity values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
