import {evaluateFeature} from '../featureEngine';
export const module={id:112,slug:'bulk-modulus-check',title:'Bulk modulus check',metric:'bulk_modulus',unit:'GPa',rule:'positive',description:'Validates positive bulk modulus.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
