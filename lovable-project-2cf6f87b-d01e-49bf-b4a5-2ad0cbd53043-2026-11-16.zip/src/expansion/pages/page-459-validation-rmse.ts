import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:459,slug:'validation-rmse',title:'Validation Rmse',metric:'validation_rmse',unit:'—',rule:'nonnegative',description:'Checks validation rmse for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
