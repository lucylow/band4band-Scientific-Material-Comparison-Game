import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:260,slug:'elastic-anisotropy-index',title:'Elastic anisotropy index',metric:'elastic_anisotropy',unit:'dimensionless',rule:'nonnegative',description:'Screens elastic anisotropy index values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
