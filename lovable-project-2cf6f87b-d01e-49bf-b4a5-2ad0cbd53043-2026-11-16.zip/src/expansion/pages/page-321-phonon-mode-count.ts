import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:321,slug:'phonon-mode-count',title:'Phonon mode count',metric:'phonon_modes',unit:'modes',rule:'positive_integer',description:'Checks a supplied phonon mode count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
