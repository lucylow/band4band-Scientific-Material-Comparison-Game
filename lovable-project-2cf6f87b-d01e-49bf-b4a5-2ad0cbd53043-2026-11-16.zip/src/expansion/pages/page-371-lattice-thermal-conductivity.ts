import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:371,slug:'lattice-thermal-conductivity',title:'Lattice thermal conductivity',metric:'kappa_lattice',unit:'W/m·K',rule:'nonnegative',description:'Checks a supplied lattice thermal conductivity value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
