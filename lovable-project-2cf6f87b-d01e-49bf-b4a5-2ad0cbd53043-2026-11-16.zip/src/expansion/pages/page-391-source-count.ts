import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:391,slug:'source-count',title:'Independent source count',metric:'source_count',unit:'sources',rule:'positive_integer',description:'Checks a supplied independent source count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
