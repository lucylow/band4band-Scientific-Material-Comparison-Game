import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:256,slug:'pore-fraction',title:'Pore fraction',metric:'pore_fraction',unit:'%',rule:'percent',description:'Screens pore fraction values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
