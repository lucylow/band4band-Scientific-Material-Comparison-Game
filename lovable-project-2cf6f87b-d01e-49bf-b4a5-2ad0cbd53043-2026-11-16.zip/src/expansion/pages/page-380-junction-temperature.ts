import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:380,slug:'junction-temperature',title:'Junction temperature',metric:'junction_temperature',unit:'K',rule:'positive',description:'Checks a supplied junction temperature value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
