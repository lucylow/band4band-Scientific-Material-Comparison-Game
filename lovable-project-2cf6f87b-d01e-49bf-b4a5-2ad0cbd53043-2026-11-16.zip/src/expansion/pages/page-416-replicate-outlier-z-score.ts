import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:416,slug:'replicate-outlier-z-score',title:'Replicate Outlier Z Score',metric:'replicate_outlier_z_score',unit:'—',rule:'nonnegative',description:'Checks replicate outlier z score for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
