import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:387,slug:'pair-distance-spread',title:'Bond distance spread',metric:'bond_distance_std',unit:'Å',rule:'nonnegative',description:'Checks a supplied bond distance spread value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
