import {evaluateFeature} from '../featureEngine';
export const module={id:190,slug:'embodied-carbon-check',title:'Embodied carbon check',metric:'embodied_carbon',unit:'kgCO₂e/kg',rule:'nonnegative',description:'Checks non-negative embodied carbon.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
