import {evaluateFeature} from '../featureEngine';
export const module={id:177,slug:'dislocation-density-check',title:'Dislocation density check',metric:'dislocation_density',unit:'m⁻²',rule:'nonnegative',description:'Checks non-negative dislocation density.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
