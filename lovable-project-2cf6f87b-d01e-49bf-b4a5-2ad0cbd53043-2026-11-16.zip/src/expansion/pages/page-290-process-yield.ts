import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:290,slug:'process-yield',title:'Manufacturing process yield',metric:'process_yield',unit:'%',rule:'percent',description:'Screens manufacturing process yield values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
