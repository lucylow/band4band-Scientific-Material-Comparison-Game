import {evaluateFeature} from '../featureEngine';
export const module={id:181,slug:'switching-loss-check',title:'Switching loss check',metric:'switching_loss',unit:'J',rule:'nonnegative',description:'Checks non-negative switching energy.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
