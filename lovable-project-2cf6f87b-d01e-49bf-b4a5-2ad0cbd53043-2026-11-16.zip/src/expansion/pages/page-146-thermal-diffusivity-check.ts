import {evaluateFeature} from '../featureEngine';
export const module={id:146,slug:'thermal-diffusivity-check',title:'Thermal diffusivity check',metric:'thermal_diffusivity',unit:'m²/s',rule:'positive',description:'Checks positive thermal diffusivity.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
