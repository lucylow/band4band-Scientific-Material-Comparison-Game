import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:309,slug:'spin-splitting',title:'Spin splitting',metric:'spin_splitting',unit:'eV',rule:'nonnegative',description:'Checks a supplied spin splitting value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
