import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:255,slug:'grain-size-distribution',title:'Grain size distribution width',metric:'grain_size_spread',unit:'nm',rule:'nonnegative',description:'Screens grain size distribution width values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
