import {evaluateFeature} from '../featureEngine';
export const module={id:133,slug:'site-count-check',title:'Atomic site count check',metric:'site_count',unit:'count',rule:'integer',description:'Validates integer atom count.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
