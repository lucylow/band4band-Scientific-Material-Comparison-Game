import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:361,slug:'dos-fermi',title:'DOS at Fermi level',metric:'dos_fermi',unit:'states/eV',rule:'nonnegative',description:'Checks a supplied dos at fermi level value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
