import {evaluateFeature} from '../featureEngine';
export const module={id:106,slug:'density-window',title:'Density window',metric:'density',unit:'kg/m³',rule:'range',description:'Checks an application-defined density window.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
