import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:419,slug:'replicate-within-lab-spread',title:'Replicate Within Lab Spread',metric:'replicate_within_lab_spread',unit:'—',rule:'nonnegative',description:'Checks replicate within lab spread for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
