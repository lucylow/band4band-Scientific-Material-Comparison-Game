import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:323,slug:'imaginary-frequency',title:'Imaginary frequency magnitude',metric:'imaginary_frequency',unit:'THz',rule:'nonnegative',description:'Checks a supplied imaginary frequency magnitude value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
