import {evaluateFeature} from '../featureEngine';
export const module={id:126,slug:'lattice-a-check',title:'Lattice a check',metric:'lattice_a',unit:'Å',rule:'positive',description:'Validates positive lattice parameter a.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
