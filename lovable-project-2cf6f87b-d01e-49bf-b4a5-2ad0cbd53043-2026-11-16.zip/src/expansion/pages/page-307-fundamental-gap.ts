import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:307,slug:'fundamental-gap',title:'Fundamental band gap',metric:'fundamental_gap',unit:'eV',rule:'nonnegative',description:'Checks a supplied fundamental band gap value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
