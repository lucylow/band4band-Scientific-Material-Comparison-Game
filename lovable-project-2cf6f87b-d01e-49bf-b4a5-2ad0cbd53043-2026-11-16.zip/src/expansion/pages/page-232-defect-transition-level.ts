import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:232,slug:'defect-transition-level',title:'Defect transition level',metric:'defect_transition',unit:'eV',rule:'signed',description:'Screens defect transition level values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
