import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:460,slug:'validation-mae',title:'Validation Mae',metric:'validation_mae',unit:'—',rule:'nonnegative',description:'Checks validation mae for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
