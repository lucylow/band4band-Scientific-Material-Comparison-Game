import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:334,slug:'extinction-coefficient',title:'Extinction coefficient',metric:'extinction',unit:'dimensionless',rule:'nonnegative',description:'Checks a supplied extinction coefficient value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
