import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:467,slug:'model-bias',title:'Model Bias',metric:'model_bias',unit:'—',rule:'signed',description:'Checks model bias for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
