import {evaluateFeature} from '../featureEngine';
export const module={id:134,slug:'space-group-check',title:'Space group check',metric:'space_group_number',unit:'number',rule:'spacegroup',description:'Checks international space-group number range.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
