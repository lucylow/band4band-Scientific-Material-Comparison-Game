import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:291,slug:'batch-variation',title:'Batch-to-batch variation',metric:'batch_variation',unit:'%',rule:'nonnegative',description:'Screens batch-to-batch variation values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
