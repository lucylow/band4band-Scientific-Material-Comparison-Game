import {evaluateFeature} from '../featureEngine';
export const module={id:113,slug:'shear-modulus-check',title:'Shear modulus check',metric:'shear_modulus',unit:'GPa',rule:'positive',description:'Validates positive shear modulus.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
