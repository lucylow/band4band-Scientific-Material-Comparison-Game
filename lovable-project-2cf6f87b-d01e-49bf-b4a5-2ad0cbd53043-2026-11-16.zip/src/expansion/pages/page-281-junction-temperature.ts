import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:281,slug:'junction-temperature',title:'Junction temperature',metric:'junction_temp',unit:'K',rule:'positive',description:'Screens junction temperature values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
