import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:335,slug:'absorption-edge',title:'Absorption edge',metric:'absorption_edge',unit:'eV',rule:'positive',description:'Checks a supplied absorption edge value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
