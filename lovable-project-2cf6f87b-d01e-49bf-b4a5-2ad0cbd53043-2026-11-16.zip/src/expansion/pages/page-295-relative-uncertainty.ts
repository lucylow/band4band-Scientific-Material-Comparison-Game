import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:295,slug:'relative-uncertainty',title:'Relative uncertainty',metric:'relative_uncertainty',unit:'%',rule:'percent',description:'Screens relative uncertainty values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
