import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:336,slug:'absorption-coefficient',title:'Absorption coefficient',metric:'absorption_coefficient',unit:'cm⁻¹',rule:'nonnegative',description:'Checks a supplied absorption coefficient value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
