import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:220,slug:'photoluminescence-peak',title:'Photoluminescence peak',metric:'pl_peak',unit:'nm',rule:'positive',description:'Screens photoluminescence peak values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
