import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:358,slug:'hull-distance',title:'Distance to convex hull',metric:'hull_distance',unit:'eV/atom',rule:'nonnegative',description:'Checks a supplied distance to convex hull value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
