import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:377,slug:'thermal-expansion',title:'Linear thermal expansion',metric:'thermal_expansion',unit:'K⁻¹',rule:'signed',description:'Checks a supplied linear thermal expansion value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
