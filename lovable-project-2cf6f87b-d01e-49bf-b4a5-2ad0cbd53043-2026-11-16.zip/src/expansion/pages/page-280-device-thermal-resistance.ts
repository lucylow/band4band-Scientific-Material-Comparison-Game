import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:280,slug:'device-thermal-resistance',title:'Device thermal resistance',metric:'rth',unit:'K/W',rule:'nonnegative',description:'Screens device thermal resistance values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
