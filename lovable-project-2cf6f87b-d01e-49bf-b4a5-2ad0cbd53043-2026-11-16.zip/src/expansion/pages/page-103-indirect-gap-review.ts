import {evaluateFeature} from '../featureEngine';
export const module={id:103,slug:'indirect-gap-review',title:'Indirect gap evidence review',metric:'indirect_gap',unit:'boolean',rule:'boolean',description:'Checks whether indirect-gap metadata is explicitly present.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
