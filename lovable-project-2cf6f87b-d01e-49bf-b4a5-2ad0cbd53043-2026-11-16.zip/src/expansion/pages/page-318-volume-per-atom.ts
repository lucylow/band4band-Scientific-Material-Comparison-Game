import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:318,slug:'volume-per-atom',title:'Volume per atom',metric:'volume_per_atom',unit:'Å³/atom',rule:'positive',description:'Checks a supplied volume per atom value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
