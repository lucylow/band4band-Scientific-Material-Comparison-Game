import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:374,slug:'seebeck-magnitude',title:'Seebeck magnitude',metric:'seebeck',unit:'µV/K',rule:'nonnegative',description:'Checks a supplied seebeck magnitude value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
