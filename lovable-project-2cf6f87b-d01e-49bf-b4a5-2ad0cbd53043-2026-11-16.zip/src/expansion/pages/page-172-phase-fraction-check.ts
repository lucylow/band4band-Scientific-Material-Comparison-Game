import {evaluateFeature} from '../featureEngine';
export const module={id:172,slug:'phase-fraction-check',title:'Phase fraction check',metric:'phase_fraction',unit:'%',rule:'percent',description:'Checks phase fractions between zero and one hundred percent.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
