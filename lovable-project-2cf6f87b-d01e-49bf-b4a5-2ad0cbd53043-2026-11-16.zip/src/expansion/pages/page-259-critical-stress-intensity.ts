import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:259,slug:'critical-stress-intensity',title:'Critical stress intensity',metric:'kic',unit:'MPa·√m',rule:'nonnegative',description:'Screens critical stress intensity values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
