import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:465,slug:'model-mae',title:'Model Mae',metric:'model_mae',unit:'—',rule:'nonnegative',description:'Checks model mae for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
