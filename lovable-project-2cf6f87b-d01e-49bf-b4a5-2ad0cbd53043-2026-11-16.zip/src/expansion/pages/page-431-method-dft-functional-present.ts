import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:431,slug:'method-dft-functional-present',title:'Method Dft Functional Present',metric:'method_dft_functional_present',unit:'—',rule:'fraction',description:'Checks method dft functional present for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
