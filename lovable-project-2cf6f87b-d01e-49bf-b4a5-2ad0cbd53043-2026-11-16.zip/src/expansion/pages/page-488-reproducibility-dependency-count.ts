import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:488,slug:'reproducibility-dependency-count',title:'Reproducibility Dependency Count',metric:'reproducibility_dependency_count',unit:'—',rule:'positive_integer',description:'Checks reproducibility dependency count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
