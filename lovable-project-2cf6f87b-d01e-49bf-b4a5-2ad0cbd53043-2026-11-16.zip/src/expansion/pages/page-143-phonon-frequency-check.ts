import {evaluateFeature} from '../featureEngine';
export const module={id:143,slug:'phonon-frequency-check',title:'Phonon frequency check',metric:'phonon_frequency',unit:'THz',rule:'finite',description:'Checks finite phonon frequency data.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
