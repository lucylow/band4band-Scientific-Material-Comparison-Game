import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:487,slug:'reproducibility-workflow-version',title:'Reproducibility Workflow Version',metric:'reproducibility_workflow_version',unit:'—',rule:'positive',description:'Checks reproducibility workflow version for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
