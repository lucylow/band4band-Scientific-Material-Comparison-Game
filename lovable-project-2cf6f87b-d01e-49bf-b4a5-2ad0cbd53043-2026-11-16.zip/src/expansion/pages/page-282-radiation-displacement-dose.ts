import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:282,slug:'radiation-displacement-dose',title:'Displacement damage dose',metric:'ddd',unit:'MeV/g',rule:'nonnegative',description:'Screens displacement damage dose values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
