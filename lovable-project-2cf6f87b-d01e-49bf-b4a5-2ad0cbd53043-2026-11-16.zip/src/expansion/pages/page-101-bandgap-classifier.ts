import {evaluateFeature} from '../featureEngine';
export const module={id:101,slug:'bandgap-classifier',title:'Bandgap classifier',metric:'band_gap',unit:'eV',rule:'positive',description:'Classifies positive, zero and missing bandgap records.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
