import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:308,slug:'direct-gap',title:'Direct gap on sampled path',metric:'direct_gap',unit:'eV',rule:'nonnegative',description:'Checks a supplied direct gap on sampled path value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
