import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:348,slug:'interface-energy',title:'Interface energy',metric:'interface_energy',unit:'J/m²',rule:'signed',description:'Checks a supplied interface energy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
