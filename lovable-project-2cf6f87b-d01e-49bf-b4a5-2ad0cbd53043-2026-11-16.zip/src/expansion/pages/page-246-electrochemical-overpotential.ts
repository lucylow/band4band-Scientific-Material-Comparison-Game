import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:246,slug:'electrochemical-overpotential',title:'Electrochemical overpotential',metric:'overpotential',unit:'V',rule:'nonnegative',description:'Screens electrochemical overpotential values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
