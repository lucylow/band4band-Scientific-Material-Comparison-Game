import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:236,slug:'fermi-level-offset',title:'Fermi-level offset',metric:'fermi_offset',unit:'eV',rule:'signed',description:'Screens fermi-level offset values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
