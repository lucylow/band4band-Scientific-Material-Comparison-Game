import {evaluateFeature} from '../featureEngine';
export const module={id:102,slug:'direct-gap-review',title:'Direct gap evidence review',metric:'direct_gap',unit:'boolean',rule:'boolean',description:'Checks whether direct-gap metadata is explicitly present.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
