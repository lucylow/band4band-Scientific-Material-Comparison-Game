import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:201,slug:'phonon-density-of-states',title:'Phonon density of states',metric:'phonon_dos',unit:'states/eV',rule:'nonnegative',description:'Screens phonon density of states values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
