import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:278,slug:'threshold-voltage',title:'Threshold voltage',metric:'threshold_voltage',unit:'V',rule:'signed',description:'Screens threshold voltage values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
