import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:329,slug:'heat-capacity',title:'Heat capacity',metric:'heat_capacity',unit:'J/mol·K',rule:'positive',description:'Checks a supplied heat capacity value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
