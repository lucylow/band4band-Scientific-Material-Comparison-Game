import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:340,slug:'transmittance',title:'Transmittance',metric:'transmittance',unit:'fraction',rule:'fraction',description:'Checks a supplied transmittance value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
