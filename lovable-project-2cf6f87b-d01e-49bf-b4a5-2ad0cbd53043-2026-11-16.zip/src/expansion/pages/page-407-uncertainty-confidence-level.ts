import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:407,slug:'uncertainty-confidence-level',title:'Uncertainty Confidence Level',metric:'uncertainty_confidence_level',unit:'—',rule:'percent',description:'Checks uncertainty confidence level for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
