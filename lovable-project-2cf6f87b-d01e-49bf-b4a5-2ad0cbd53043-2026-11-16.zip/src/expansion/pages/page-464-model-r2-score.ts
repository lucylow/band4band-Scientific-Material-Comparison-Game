import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:464,slug:'model-r2-score',title:'Model R2 Score',metric:'model_r2_score',unit:'—',rule:'signed',description:'Checks model r2 score for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
