import {evaluateFeature} from '../featureEngine';
export const module={id:193,slug:'measurement-temperature-check',title:'Measurement temperature',metric:'measurement_temperature',unit:'K',rule:'positive',description:'Checks positive absolute measurement temperature.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
