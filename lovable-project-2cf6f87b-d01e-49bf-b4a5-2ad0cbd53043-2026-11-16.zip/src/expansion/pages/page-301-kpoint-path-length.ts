import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:301,slug:'kpoint-path-length',title:'K-point path length',metric:'k_path_length',unit:'Å⁻¹',rule:'positive',description:'Checks a supplied k-point path length value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
