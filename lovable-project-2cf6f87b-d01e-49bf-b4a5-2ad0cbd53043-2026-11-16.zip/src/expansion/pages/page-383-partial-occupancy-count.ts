import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:383,slug:'partial-occupancy-count',title:'Partial occupancy site count',metric:'partial_occupancy_count',unit:'sites',rule:'nonnegative',description:'Checks a supplied partial occupancy site count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
