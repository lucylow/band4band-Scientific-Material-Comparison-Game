import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:444,slug:'experimental-sample-purity',title:'Experimental Sample Purity',metric:'experimental_sample_purity',unit:'—',rule:'percent',description:'Checks experimental sample purity for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
