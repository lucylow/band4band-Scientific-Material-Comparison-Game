import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:442,slug:'experimental-pressure',title:'Experimental Pressure',metric:'experimental_pressure',unit:'—',rule:'nonnegative',description:'Checks experimental pressure for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
