import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:414,slug:'replicate-standard-error',title:'Replicate Standard Error',metric:'replicate_standard_error',unit:'—',rule:'nonnegative',description:'Checks replicate standard error for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
