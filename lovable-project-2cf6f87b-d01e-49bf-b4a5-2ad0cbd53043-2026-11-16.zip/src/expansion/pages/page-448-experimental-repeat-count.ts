import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:448,slug:'experimental-repeat-count',title:'Experimental Repeat Count',metric:'experimental_repeat_count',unit:'—',rule:'positive_integer',description:'Checks experimental repeat count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
