import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:477,slug:'dataset-composition-coverage',title:'Dataset Composition Coverage',metric:'dataset_composition_coverage',unit:'—',rule:'percent',description:'Checks dataset composition coverage for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
