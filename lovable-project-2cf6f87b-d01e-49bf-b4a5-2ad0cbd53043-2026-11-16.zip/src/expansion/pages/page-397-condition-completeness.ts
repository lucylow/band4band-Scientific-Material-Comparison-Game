import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:397,slug:'condition-completeness',title:'Condition metadata completeness',metric:'condition_completeness',unit:'%',rule:'percent',description:'Checks a supplied condition metadata completeness value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
