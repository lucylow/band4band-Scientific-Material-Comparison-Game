import {evaluateFeature} from '../featureEngine';
export const module={id:108,slug:'specific-heat-check',title:'Specific heat check',metric:'specific_heat',unit:'J/(kg·K)',rule:'positive',description:'Validates positive heat capacity.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
