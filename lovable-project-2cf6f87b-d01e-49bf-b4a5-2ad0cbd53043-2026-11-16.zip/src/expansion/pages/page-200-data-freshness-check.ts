import {evaluateFeature} from '../featureEngine';
export const module={id:200,slug:'data-freshness-check',title:'Data freshness',metric:'age_days',unit:'days',rule:'nonnegative',description:'Checks non-negative age of retrieved record.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
