import {evaluateFeature} from '../featureEngine';
export const module={id:174,slug:'stoichiometry-check',title:'Stoichiometry check',metric:'stoichiometry_error',unit:'%',rule:'nonnegative',description:'Checks non-negative stoichiometry deviation.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
