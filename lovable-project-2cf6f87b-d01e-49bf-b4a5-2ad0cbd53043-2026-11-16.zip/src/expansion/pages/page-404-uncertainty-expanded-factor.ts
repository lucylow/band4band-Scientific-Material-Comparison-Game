import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:404,slug:'uncertainty-expanded-factor',title:'Uncertainty Expanded Factor',metric:'uncertainty_expanded_factor',unit:'—',rule:'positive',description:'Checks uncertainty expanded factor for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
