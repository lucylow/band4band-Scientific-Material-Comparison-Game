import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:304,slug:'fermi-level',title:'Fermi level',metric:'fermi_level',unit:'eV',rule:'signed',description:'Checks a supplied fermi level value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
