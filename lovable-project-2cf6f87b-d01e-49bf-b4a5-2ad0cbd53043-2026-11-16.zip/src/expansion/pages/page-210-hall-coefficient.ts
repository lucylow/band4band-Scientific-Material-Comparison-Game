import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:210,slug:'hall-coefficient',title:'Hall coefficient',metric:'hall_coefficient',unit:'m³/C',rule:'signed',description:'Screens hall coefficient values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
