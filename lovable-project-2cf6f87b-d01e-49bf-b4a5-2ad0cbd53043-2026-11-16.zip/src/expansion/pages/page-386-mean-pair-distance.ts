import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:386,slug:'mean-pair-distance',title:'Mean pair distance',metric:'mean_distance',unit:'Å',rule:'positive',description:'Checks a supplied mean pair distance value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
