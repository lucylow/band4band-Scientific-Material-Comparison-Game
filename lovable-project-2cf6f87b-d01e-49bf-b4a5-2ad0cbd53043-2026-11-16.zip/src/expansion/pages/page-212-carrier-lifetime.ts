import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:212,slug:'carrier-lifetime',title:'Carrier lifetime',metric:'carrier_lifetime',unit:'s',rule:'positive',description:'Screens carrier lifetime values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
