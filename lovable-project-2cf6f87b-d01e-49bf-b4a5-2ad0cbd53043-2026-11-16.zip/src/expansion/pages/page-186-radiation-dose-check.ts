import {evaluateFeature} from '../featureEngine';
export const module={id:186,slug:'radiation-dose-check',title:'Radiation dose check',metric:'radiation_dose',unit:'Gy',rule:'nonnegative',description:'Checks non-negative radiation dose.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
