import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:245,slug:'catalytic-turnover-frequency',title:'Catalytic turnover frequency',metric:'tof',unit:'s⁻¹',rule:'nonnegative',description:'Screens catalytic turnover frequency values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
