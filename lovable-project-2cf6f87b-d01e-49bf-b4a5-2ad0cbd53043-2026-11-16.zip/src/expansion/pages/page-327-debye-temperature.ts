import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:327,slug:'debye-temperature',title:'Debye temperature',metric:'debye_temperature',unit:'K',rule:'positive',description:'Checks a supplied debye temperature value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
