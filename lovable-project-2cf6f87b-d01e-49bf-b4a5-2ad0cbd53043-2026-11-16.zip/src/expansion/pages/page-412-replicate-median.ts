import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:412,slug:'replicate-median',title:'Replicate Median',metric:'replicate_median',unit:'—',rule:'signed',description:'Checks replicate median for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
