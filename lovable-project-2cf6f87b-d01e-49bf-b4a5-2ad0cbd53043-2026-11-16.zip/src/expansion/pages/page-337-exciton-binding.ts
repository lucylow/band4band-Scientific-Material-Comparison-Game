import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:337,slug:'exciton-binding',title:'Exciton binding energy',metric:'exciton_binding',unit:'eV',rule:'nonnegative',description:'Checks a supplied exciton binding energy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
