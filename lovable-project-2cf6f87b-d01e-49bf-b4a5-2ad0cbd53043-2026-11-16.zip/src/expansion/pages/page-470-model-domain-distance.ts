import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:470,slug:'model-domain-distance',title:'Model Domain Distance',metric:'model_domain_distance',unit:'—',rule:'nonnegative',description:'Checks model domain distance for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
