import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:314,slug:'lattice-angle-alpha',title:'Lattice angle alpha',metric:'alpha',unit:'degrees',rule:'angle',description:'Checks a supplied lattice angle alpha value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
