import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:239,slug:'interface-state-density',title:'Interface state density',metric:'interface_states',unit:'cm⁻²eV⁻¹',rule:'nonnegative',description:'Screens interface state density values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
