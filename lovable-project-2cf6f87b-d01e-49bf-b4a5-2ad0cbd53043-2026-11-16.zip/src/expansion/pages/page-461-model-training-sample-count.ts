import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:461,slug:'model-training-sample-count',title:'Model Training Sample Count',metric:'model_training_sample_count',unit:'—',rule:'positive_integer',description:'Checks model training sample count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
