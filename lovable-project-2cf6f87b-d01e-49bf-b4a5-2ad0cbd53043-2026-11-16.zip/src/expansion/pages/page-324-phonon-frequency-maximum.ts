import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:324,slug:'phonon-frequency-maximum',title:'Maximum phonon frequency',metric:'phonon_max',unit:'THz',rule:'positive',description:'Checks a supplied maximum phonon frequency value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
