import {evaluateFeature} from '../featureEngine';
export const module={id:150,slug:'zT-check',title:'Thermoelectric figure of merit',metric:'zt',unit:'1',rule:'nonnegative',description:'Checks non-negative dimensionless thermoelectric figure of merit.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
