import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:452,slug:'validation-percent-deviation',title:'Validation Percent Deviation',metric:'validation_percent_deviation',unit:'—',rule:'nonnegative',description:'Checks validation percent deviation for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
