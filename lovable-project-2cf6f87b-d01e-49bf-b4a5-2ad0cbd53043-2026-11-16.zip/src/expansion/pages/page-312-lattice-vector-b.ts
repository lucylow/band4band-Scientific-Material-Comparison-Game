import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:312,slug:'lattice-vector-b',title:'Lattice vector b length',metric:'lattice_b',unit:'Å',rule:'positive',description:'Checks a supplied lattice vector b length value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
