import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:261,slug:'thermal-shock-parameter',title:'Thermal shock parameter',metric:'thermal_shock',unit:'K',rule:'positive',description:'Screens thermal shock parameter values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
