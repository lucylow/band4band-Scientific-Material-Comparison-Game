import {evaluateFeature} from '../featureEngine';
export const module={id:192,slug:'criticality-check',title:'Criticality score check',metric:'criticality',unit:'score',rule:'range',description:'Checks configured criticality score.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
