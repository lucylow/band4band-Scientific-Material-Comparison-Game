import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:296,slug:'sample-count',title:'Sample count',metric:'sample_count',unit:'count',rule:'positive_integer',description:'Screens sample count values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
