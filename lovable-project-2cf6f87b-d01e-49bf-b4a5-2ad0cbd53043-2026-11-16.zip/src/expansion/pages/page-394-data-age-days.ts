import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:394,slug:'data-age-days',title:'Data age',metric:'data_age_days',unit:'days',rule:'nonnegative',description:'Checks a supplied data age value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
