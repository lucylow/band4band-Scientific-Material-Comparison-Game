import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:478,slug:'dataset-property-coverage',title:'Dataset Property Coverage',metric:'dataset_property_coverage',unit:'—',rule:'percent',description:'Checks dataset property coverage for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
