import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:273,slug:'breakdown-probability',title:'Breakdown probability',metric:'breakdown_probability',unit:'%',rule:'percent',description:'Screens breakdown probability values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
