import {evaluateFeature} from '../featureEngine';
export const module={id:110,slug:'melting-point-check',title:'Melting point check',metric:'melting_point',unit:'K',rule:'positive',description:'Validates positive absolute melting temperature.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
