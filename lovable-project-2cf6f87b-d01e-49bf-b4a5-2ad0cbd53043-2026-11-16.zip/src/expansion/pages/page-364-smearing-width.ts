import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:364,slug:'smearing-width',title:'Fermi smearing width',metric:'smearing_width',unit:'eV',rule:'positive',description:'Checks a supplied fermi smearing width value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
