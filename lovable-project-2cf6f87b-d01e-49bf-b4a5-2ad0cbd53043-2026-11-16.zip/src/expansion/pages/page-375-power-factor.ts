import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:375,slug:'power-factor',title:'Thermoelectric power factor',metric:'power_factor',unit:'W/m·K²',rule:'nonnegative',description:'Checks a supplied thermoelectric power factor value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
