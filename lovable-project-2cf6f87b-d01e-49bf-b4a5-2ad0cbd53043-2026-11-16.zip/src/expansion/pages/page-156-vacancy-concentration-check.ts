import {evaluateFeature} from '../featureEngine';
export const module={id:156,slug:'vacancy-concentration-check',title:'Vacancy concentration check',metric:'vacancy_concentration',unit:'cm⁻³',rule:'nonnegative',description:'Checks non-negative vacancy concentration.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
