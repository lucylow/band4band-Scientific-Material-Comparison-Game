import {evaluateFeature} from '../featureEngine';
export const module={id:173,slug:'composition-sum-check',title:'Composition sum check',metric:'composition_sum',unit:'%',rule:'composition',description:'Checks composition totals near 100 percent.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
