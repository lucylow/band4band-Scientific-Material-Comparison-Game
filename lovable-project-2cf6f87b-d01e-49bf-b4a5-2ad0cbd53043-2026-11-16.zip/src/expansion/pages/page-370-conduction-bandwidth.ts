import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:370,slug:'conduction-bandwidth',title:'Conduction bandwidth',metric:'conduction_bandwidth',unit:'eV',rule:'nonnegative',description:'Checks a supplied conduction bandwidth value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
