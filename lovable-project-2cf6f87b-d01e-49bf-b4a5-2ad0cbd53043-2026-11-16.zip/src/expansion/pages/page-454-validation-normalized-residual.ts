import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:454,slug:'validation-normalized-residual',title:'Validation Normalized Residual',metric:'validation_normalized_residual',unit:'—',rule:'nonnegative',description:'Checks validation normalized residual for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
