import {evaluateFeature} from '../featureEngine';
export const module={id:197,slug:'citation-check',title:'Citation completeness',metric:'citation_count',unit:'count',rule:'integer',description:'Checks non-negative citation count.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
