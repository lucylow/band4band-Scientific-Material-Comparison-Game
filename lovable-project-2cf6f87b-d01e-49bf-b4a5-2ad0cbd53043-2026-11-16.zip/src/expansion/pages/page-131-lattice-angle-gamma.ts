import {evaluateFeature} from '../featureEngine';
export const module={id:131,slug:'lattice-angle-gamma',title:'Lattice gamma check',metric:'gamma',unit:'degree',rule:'angle',description:'Checks crystallographic angle gamma.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
