import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:363,slug:'projected-dos-error',title:'Projected DOS sum discrepancy',metric:'pdos_sum_error',unit:'%',rule:'percent',description:'Checks a supplied projected dos sum discrepancy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
