import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:408,slug:'uncertainty-confidence-interval-lower',title:'Uncertainty Confidence Interval Lower',metric:'uncertainty_confidence_interval_lower',unit:'—',rule:'signed',description:'Checks uncertainty confidence interval lower for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
