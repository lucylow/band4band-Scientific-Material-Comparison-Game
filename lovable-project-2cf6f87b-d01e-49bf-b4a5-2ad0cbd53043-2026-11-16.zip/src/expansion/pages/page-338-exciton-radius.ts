import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:338,slug:'exciton-radius',title:'Exciton radius',metric:'exciton_radius',unit:'Å',rule:'positive',description:'Checks a supplied exciton radius value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
