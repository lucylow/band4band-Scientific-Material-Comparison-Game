import {evaluateFeature} from '../featureEngine';
export const module={id:128,slug:'lattice-c-check',title:'Lattice c check',metric:'lattice_c',unit:'Å',rule:'positive',description:'Validates positive lattice parameter c.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
