import {evaluateFeature} from '../featureEngine';
export const module={id:194,slug:'uncertainty-check',title:'Uncertainty check',metric:'uncertainty',unit:'unit',rule:'nonnegative',description:'Checks non-negative reported uncertainty.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
