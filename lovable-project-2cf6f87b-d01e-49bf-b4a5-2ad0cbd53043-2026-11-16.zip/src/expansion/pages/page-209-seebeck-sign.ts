import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:209,slug:'seebeck-sign',title:'Seebeck coefficient sign',metric:'seebeck',unit:'µV/K',rule:'signed',description:'Screens seebeck coefficient sign values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
