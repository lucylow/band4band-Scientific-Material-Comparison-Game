import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:489,slug:'reproducibility-hardware-metadata-present',title:'Reproducibility Hardware Metadata Present',metric:'reproducibility_hardware_metadata_present',unit:'—',rule:'fraction',description:'Checks reproducibility hardware metadata present for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
