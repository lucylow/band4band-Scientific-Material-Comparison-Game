import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:413,slug:'replicate-range',title:'Replicate Range',metric:'replicate_range',unit:'—',rule:'nonnegative',description:'Checks replicate range for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
