import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:274,slug:'leakage-density',title:'Leakage current density',metric:'leakage_density',unit:'A/cm²',rule:'nonnegative',description:'Screens leakage current density values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
