import {evaluateFeature} from '../featureEngine';
export const module={id:155,slug:'defect-formation-check',title:'Defect formation energy',metric:'defect_formation_energy',unit:'eV',rule:'finite',description:'Checks finite defect formation energy.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
