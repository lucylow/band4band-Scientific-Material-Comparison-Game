import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:228,slug:'substitution-energy',title:'Substitution energy',metric:'substitution_energy',unit:'eV',rule:'signed',description:'Screens substitution energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
