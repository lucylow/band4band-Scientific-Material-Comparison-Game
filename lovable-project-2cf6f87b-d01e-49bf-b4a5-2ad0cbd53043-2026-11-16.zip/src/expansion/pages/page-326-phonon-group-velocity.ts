import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:326,slug:'phonon-group-velocity',title:'Phonon group velocity',metric:'phonon_velocity',unit:'m/s',rule:'nonnegative',description:'Checks a supplied phonon group velocity value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
