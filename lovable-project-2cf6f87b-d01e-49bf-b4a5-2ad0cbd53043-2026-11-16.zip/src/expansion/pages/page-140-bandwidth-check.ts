import {evaluateFeature} from '../featureEngine';
export const module={id:140,slug:'bandwidth-check',title:'Electronic bandwidth check',metric:'bandwidth',unit:'eV',rule:'nonnegative',description:'Checks non-negative band width.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
