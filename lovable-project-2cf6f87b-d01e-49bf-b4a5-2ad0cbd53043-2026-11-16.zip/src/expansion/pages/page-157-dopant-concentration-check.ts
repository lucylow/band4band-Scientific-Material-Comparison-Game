import {evaluateFeature} from '../featureEngine';
export const module={id:157,slug:'dopant-concentration-check',title:'Dopant concentration check',metric:'dopant_concentration',unit:'cm⁻³',rule:'nonnegative',description:'Checks non-negative dopant concentration.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
