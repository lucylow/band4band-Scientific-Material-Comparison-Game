import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:435,slug:'method-convergence-threshold',title:'Method Convergence Threshold',metric:'method_convergence_threshold',unit:'—',rule:'positive',description:'Checks method convergence threshold for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
