import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:248,slug:'corrosion-potential',title:'Corrosion potential',metric:'corrosion_potential',unit:'V',rule:'signed',description:'Screens corrosion potential values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
