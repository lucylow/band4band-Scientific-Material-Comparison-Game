import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:455,slug:'validation-z-score',title:'Validation Z Score',metric:'validation_z_score',unit:'—',rule:'signed',description:'Checks validation z score for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
