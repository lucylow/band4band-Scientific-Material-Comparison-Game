import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:411,slug:'replicate-mean',title:'Replicate Mean',metric:'replicate_mean',unit:'—',rule:'signed',description:'Checks replicate mean for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
