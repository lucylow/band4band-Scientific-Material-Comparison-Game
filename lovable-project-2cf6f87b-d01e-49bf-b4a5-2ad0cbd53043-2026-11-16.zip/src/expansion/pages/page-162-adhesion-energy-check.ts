import {evaluateFeature} from '../featureEngine';
export const module={id:162,slug:'adhesion-energy-check',title:'Adhesion energy check',metric:'adhesion_energy',unit:'J/m²',rule:'finite',description:'Checks finite adhesion energy.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
