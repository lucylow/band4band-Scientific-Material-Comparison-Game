import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:420,slug:'replicate-reproducibility-ratio',title:'Replicate Reproducibility Ratio',metric:'replicate_reproducibility_ratio',unit:'—',rule:'nonnegative',description:'Checks replicate reproducibility ratio for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
