import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:213,slug:'diffusion-length',title:'Carrier diffusion length',metric:'diffusion_length',unit:'m',rule:'positive',description:'Screens carrier diffusion length values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
