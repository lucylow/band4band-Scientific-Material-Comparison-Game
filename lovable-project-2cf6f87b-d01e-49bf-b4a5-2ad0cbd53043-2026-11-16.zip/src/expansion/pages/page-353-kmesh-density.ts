import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:353,slug:'kmesh-density',title:'K-point mesh density',metric:'kmesh_density',unit:'points/Å⁻³',rule:'positive',description:'Checks a supplied k-point mesh density value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
