import {evaluateFeature} from '../featureEngine';
export const module={id:176,slug:'grain-size-check',title:'Grain size check',metric:'grain_size',unit:'μm',rule:'positive',description:'Checks positive grain size.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
