import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:428,slug:'provenance-license-present',title:'Provenance License Present',metric:'provenance_license_present',unit:'—',rule:'fraction',description:'Checks provenance license present for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
