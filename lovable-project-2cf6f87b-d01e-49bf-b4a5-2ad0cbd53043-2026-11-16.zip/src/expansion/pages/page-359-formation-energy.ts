import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:359,slug:'formation-energy',title:'Formation energy',metric:'formation_energy',unit:'eV/atom',rule:'signed',description:'Checks a supplied formation energy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
