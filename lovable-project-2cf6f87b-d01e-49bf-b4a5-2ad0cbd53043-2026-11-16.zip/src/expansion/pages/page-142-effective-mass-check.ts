import {evaluateFeature} from '../featureEngine';
export const module={id:142,slug:'effective-mass-check',title:'Effective mass check',metric:'effective_mass',unit:'mₑ',rule:'finite',description:'Checks finite effective mass records.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
