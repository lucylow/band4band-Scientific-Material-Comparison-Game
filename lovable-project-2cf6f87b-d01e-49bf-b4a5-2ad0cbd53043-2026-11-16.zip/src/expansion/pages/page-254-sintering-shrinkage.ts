import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:254,slug:'sintering-shrinkage',title:'Sintering shrinkage',metric:'shrinkage',unit:'%',rule:'percent',description:'Screens sintering shrinkage values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
