import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:496,slug:'sensitivity-variance-contribution',title:'Sensitivity Variance Contribution',metric:'sensitivity_variance_contribution',unit:'—',rule:'fraction',description:'Checks sensitivity variance contribution for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
