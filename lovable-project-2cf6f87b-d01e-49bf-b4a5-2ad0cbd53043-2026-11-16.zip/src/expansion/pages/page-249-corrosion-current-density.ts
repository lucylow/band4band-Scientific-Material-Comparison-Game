import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:249,slug:'corrosion-current-density',title:'Corrosion current density',metric:'corrosion_current',unit:'A/m²',rule:'nonnegative',description:'Screens corrosion current density values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
