import {evaluateFeature} from '../featureEngine';
export const module={id:119,slug:'magnetic-moment-check',title:'Magnetic moment check',metric:'magnetic_moment',unit:'μB',rule:'nonnegative',description:'Checks non-negative magnetic moment.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
