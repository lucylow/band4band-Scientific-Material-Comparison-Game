import {evaluateAdvancedMetric} from '../advancedEngine';
import {module as m301} from './page-301-kpoint-path-length';
import {module as m302} from './page-302-kpoint-count';
import {module as m303} from './page-303-band-count';
import {module as m304} from './page-304-fermi-level';
import {module as m305} from './page-305-valence-band-maximum';
import {module as m306} from './page-306-conduction-band-minimum';
import {module as m307} from './page-307-fundamental-gap';
import {module as m308} from './page-308-direct-gap';
import {module as m309} from './page-309-spin-splitting';
import {module as m310} from './page-310-effective-mass-anisotropy';
import {module as m311} from './page-311-lattice-vector-a';
import {module as m312} from './page-312-lattice-vector-b';
import {module as m313} from './page-313-lattice-vector-c';
import {module as m314} from './page-314-lattice-angle-alpha';
import {module as m315} from './page-315-lattice-angle-beta';
import {module as m316} from './page-316-lattice-angle-gamma';
import {module as m317} from './page-317-cell-volume';
import {module as m318} from './page-318-volume-per-atom';
import {module as m319} from './page-319-explicit-site-count';
import {module as m320} from './page-320-space-group-number';
import {module as m321} from './page-321-phonon-mode-count';
import {module as m322} from './page-322-imaginary-mode-count';
import {module as m323} from './page-323-imaginary-frequency';
import {module as m324} from './page-324-phonon-frequency-maximum';
import {module as m325} from './page-325-phonon-gap';
import {module as m326} from './page-326-phonon-group-velocity';
import {module as m327} from './page-327-debye-temperature';
import {module as m328} from './page-328-gruneisen-parameter';
import {module as m329} from './page-329-heat-capacity';
import {module as m330} from './page-330-thermal-diffusivity';
import {module as m331} from './page-331-dielectric-static';
import {module as m332} from './page-332-dielectric-optical';
import {module as m333} from './page-333-refractive-index';
import {module as m334} from './page-334-extinction-coefficient';
import {module as m335} from './page-335-absorption-edge';
import {module as m336} from './page-336-absorption-coefficient';
import {module as m337} from './page-337-exciton-binding';
import {module as m338} from './page-338-exciton-radius';
import {module as m339} from './page-339-reflectance';
import {module as m340} from './page-340-transmittance';
import {module as m341} from './page-341-defect-formation-energy';
import {module as m342} from './page-342-defect-transition-level';
import {module as m343} from './page-343-defect-concentration';
import {module as m344} from './page-344-dopant-concentration';
import {module as m345} from './page-345-dopant-activation-fraction';
import {module as m346} from './page-346-migration-barrier';
import {module as m347} from './page-347-diffusion-coefficient';
import {module as m348} from './page-348-interface-energy';
import {module as m349} from './page-349-surface-energy';
import {module as m350} from './page-350-adhesion-energy';
import {module as m351} from './page-351-calculation-convergence';
import {module as m352} from './page-352-plane-wave-cutoff';
import {module as m353} from './page-353-kmesh-density';
import {module as m354} from './page-354-scf-iteration-count';
import {module as m355} from './page-355-force-residual';
import {module as m356} from './page-356-stress-residual';
import {module as m357} from './page-357-energy-per-atom';
import {module as m358} from './page-358-hull-distance';
import {module as m359} from './page-359-formation-energy';
import {module as m360} from './page-360-measurement-uncertainty';
import {module as m361} from './page-361-dos-fermi';
import {module as m362} from './page-362-dos-integral-error';
import {module as m363} from './page-363-projected-dos-error';
import {module as m364} from './page-364-smearing-width';
import {module as m365} from './page-365-occupation-error';
import {module as m366} from './page-366-electron-effective-mass';
import {module as m367} from './page-367-hole-effective-mass';
import {module as m368} from './page-368-fermi-velocity';
import {module as m369} from './page-369-valence-bandwidth';
import {module as m370} from './page-370-conduction-bandwidth';
import {module as m371} from './page-371-lattice-thermal-conductivity';
import {module as m372} from './page-372-electronic-thermal-conductivity';
import {module as m373} from './page-373-lorenz-number';
import {module as m374} from './page-374-seebeck-magnitude';
import {module as m375} from './page-375-power-factor';
import {module as m376} from './page-376-thermoelectric-zt';
import {module as m377} from './page-377-thermal-expansion';
import {module as m378} from './page-378-thermal-boundary-resistance';
import {module as m379} from './page-379-thermal-cycling-count';
import {module as m380} from './page-380-junction-temperature';
import {module as m381} from './page-381-fractional-coordinate-range';
import {module as m382} from './page-382-site-occupancy';
import {module as m383} from './page-383-partial-occupancy-count';
import {module as m384} from './page-384-minimum-pair-distance';
import {module as m385} from './page-385-maximum-pair-distance';
import {module as m386} from './page-386-mean-pair-distance';
import {module as m387} from './page-387-pair-distance-spread';
import {module as m388} from './page-388-coordination-number';
import {module as m389} from './page-389-neighbor-cutoff';
import {module as m390} from './page-390-symmetry-multiplicity';
import {module as m391} from './page-391-source-count';
import {module as m392} from './page-392-replicate-count';
import {module as m393} from './page-393-replica-gap-spread';
import {module as m394} from './page-394-data-age-days';
import {module as m395} from './page-395-citation-count';
import {module as m396} from './page-396-method-completeness';
import {module as m397} from './page-397-condition-completeness';
import {module as m398} from './page-398-unit-conversion-residual';
import {module as m399} from './page-399-uncertainty-relative';
import {module as m400} from './page-400-confidence-interval-width';
export const CRYSTAL_BAND_MODULES=[
  {...m301, evaluate:(value:number|null)=>evaluateAdvancedMetric(m301.rule,value)},
  {...m302, evaluate:(value:number|null)=>evaluateAdvancedMetric(m302.rule,value)},
  {...m303, evaluate:(value:number|null)=>evaluateAdvancedMetric(m303.rule,value)},
  {...m304, evaluate:(value:number|null)=>evaluateAdvancedMetric(m304.rule,value)},
  {...m305, evaluate:(value:number|null)=>evaluateAdvancedMetric(m305.rule,value)},
  {...m306, evaluate:(value:number|null)=>evaluateAdvancedMetric(m306.rule,value)},
  {...m307, evaluate:(value:number|null)=>evaluateAdvancedMetric(m307.rule,value)},
  {...m308, evaluate:(value:number|null)=>evaluateAdvancedMetric(m308.rule,value)},
  {...m309, evaluate:(value:number|null)=>evaluateAdvancedMetric(m309.rule,value)},
  {...m310, evaluate:(value:number|null)=>evaluateAdvancedMetric(m310.rule,value)},
  {...m311, evaluate:(value:number|null)=>evaluateAdvancedMetric(m311.rule,value)},
  {...m312, evaluate:(value:number|null)=>evaluateAdvancedMetric(m312.rule,value)},
  {...m313, evaluate:(value:number|null)=>evaluateAdvancedMetric(m313.rule,value)},
  {...m314, evaluate:(value:number|null)=>evaluateAdvancedMetric(m314.rule,value)},
  {...m315, evaluate:(value:number|null)=>evaluateAdvancedMetric(m315.rule,value)},
  {...m316, evaluate:(value:number|null)=>evaluateAdvancedMetric(m316.rule,value)},
  {...m317, evaluate:(value:number|null)=>evaluateAdvancedMetric(m317.rule,value)},
  {...m318, evaluate:(value:number|null)=>evaluateAdvancedMetric(m318.rule,value)},
  {...m319, evaluate:(value:number|null)=>evaluateAdvancedMetric(m319.rule,value)},
  {...m320, evaluate:(value:number|null)=>evaluateAdvancedMetric(m320.rule,value)},
  {...m321, evaluate:(value:number|null)=>evaluateAdvancedMetric(m321.rule,value)},
  {...m322, evaluate:(value:number|null)=>evaluateAdvancedMetric(m322.rule,value)},
  {...m323, evaluate:(value:number|null)=>evaluateAdvancedMetric(m323.rule,value)},
  {...m324, evaluate:(value:number|null)=>evaluateAdvancedMetric(m324.rule,value)},
  {...m325, evaluate:(value:number|null)=>evaluateAdvancedMetric(m325.rule,value)},
  {...m326, evaluate:(value:number|null)=>evaluateAdvancedMetric(m326.rule,value)},
  {...m327, evaluate:(value:number|null)=>evaluateAdvancedMetric(m327.rule,value)},
  {...m328, evaluate:(value:number|null)=>evaluateAdvancedMetric(m328.rule,value)},
  {...m329, evaluate:(value:number|null)=>evaluateAdvancedMetric(m329.rule,value)},
  {...m330, evaluate:(value:number|null)=>evaluateAdvancedMetric(m330.rule,value)},
  {...m331, evaluate:(value:number|null)=>evaluateAdvancedMetric(m331.rule,value)},
  {...m332, evaluate:(value:number|null)=>evaluateAdvancedMetric(m332.rule,value)},
  {...m333, evaluate:(value:number|null)=>evaluateAdvancedMetric(m333.rule,value)},
  {...m334, evaluate:(value:number|null)=>evaluateAdvancedMetric(m334.rule,value)},
  {...m335, evaluate:(value:number|null)=>evaluateAdvancedMetric(m335.rule,value)},
  {...m336, evaluate:(value:number|null)=>evaluateAdvancedMetric(m336.rule,value)},
  {...m337, evaluate:(value:number|null)=>evaluateAdvancedMetric(m337.rule,value)},
  {...m338, evaluate:(value:number|null)=>evaluateAdvancedMetric(m338.rule,value)},
  {...m339, evaluate:(value:number|null)=>evaluateAdvancedMetric(m339.rule,value)},
  {...m340, evaluate:(value:number|null)=>evaluateAdvancedMetric(m340.rule,value)},
  {...m341, evaluate:(value:number|null)=>evaluateAdvancedMetric(m341.rule,value)},
  {...m342, evaluate:(value:number|null)=>evaluateAdvancedMetric(m342.rule,value)},
  {...m343, evaluate:(value:number|null)=>evaluateAdvancedMetric(m343.rule,value)},
  {...m344, evaluate:(value:number|null)=>evaluateAdvancedMetric(m344.rule,value)},
  {...m345, evaluate:(value:number|null)=>evaluateAdvancedMetric(m345.rule,value)},
  {...m346, evaluate:(value:number|null)=>evaluateAdvancedMetric(m346.rule,value)},
  {...m347, evaluate:(value:number|null)=>evaluateAdvancedMetric(m347.rule,value)},
  {...m348, evaluate:(value:number|null)=>evaluateAdvancedMetric(m348.rule,value)},
  {...m349, evaluate:(value:number|null)=>evaluateAdvancedMetric(m349.rule,value)},
  {...m350, evaluate:(value:number|null)=>evaluateAdvancedMetric(m350.rule,value)},
  {...m351, evaluate:(value:number|null)=>evaluateAdvancedMetric(m351.rule,value)},
  {...m352, evaluate:(value:number|null)=>evaluateAdvancedMetric(m352.rule,value)},
  {...m353, evaluate:(value:number|null)=>evaluateAdvancedMetric(m353.rule,value)},
  {...m354, evaluate:(value:number|null)=>evaluateAdvancedMetric(m354.rule,value)},
  {...m355, evaluate:(value:number|null)=>evaluateAdvancedMetric(m355.rule,value)},
  {...m356, evaluate:(value:number|null)=>evaluateAdvancedMetric(m356.rule,value)},
  {...m357, evaluate:(value:number|null)=>evaluateAdvancedMetric(m357.rule,value)},
  {...m358, evaluate:(value:number|null)=>evaluateAdvancedMetric(m358.rule,value)},
  {...m359, evaluate:(value:number|null)=>evaluateAdvancedMetric(m359.rule,value)},
  {...m360, evaluate:(value:number|null)=>evaluateAdvancedMetric(m360.rule,value)},
  {...m361, evaluate:(value:number|null)=>evaluateAdvancedMetric(m361.rule,value)},
  {...m362, evaluate:(value:number|null)=>evaluateAdvancedMetric(m362.rule,value)},
  {...m363, evaluate:(value:number|null)=>evaluateAdvancedMetric(m363.rule,value)},
  {...m364, evaluate:(value:number|null)=>evaluateAdvancedMetric(m364.rule,value)},
  {...m365, evaluate:(value:number|null)=>evaluateAdvancedMetric(m365.rule,value)},
  {...m366, evaluate:(value:number|null)=>evaluateAdvancedMetric(m366.rule,value)},
  {...m367, evaluate:(value:number|null)=>evaluateAdvancedMetric(m367.rule,value)},
  {...m368, evaluate:(value:number|null)=>evaluateAdvancedMetric(m368.rule,value)},
  {...m369, evaluate:(value:number|null)=>evaluateAdvancedMetric(m369.rule,value)},
  {...m370, evaluate:(value:number|null)=>evaluateAdvancedMetric(m370.rule,value)},
  {...m371, evaluate:(value:number|null)=>evaluateAdvancedMetric(m371.rule,value)},
  {...m372, evaluate:(value:number|null)=>evaluateAdvancedMetric(m372.rule,value)},
  {...m373, evaluate:(value:number|null)=>evaluateAdvancedMetric(m373.rule,value)},
  {...m374, evaluate:(value:number|null)=>evaluateAdvancedMetric(m374.rule,value)},
  {...m375, evaluate:(value:number|null)=>evaluateAdvancedMetric(m375.rule,value)},
  {...m376, evaluate:(value:number|null)=>evaluateAdvancedMetric(m376.rule,value)},
  {...m377, evaluate:(value:number|null)=>evaluateAdvancedMetric(m377.rule,value)},
  {...m378, evaluate:(value:number|null)=>evaluateAdvancedMetric(m378.rule,value)},
  {...m379, evaluate:(value:number|null)=>evaluateAdvancedMetric(m379.rule,value)},
  {...m380, evaluate:(value:number|null)=>evaluateAdvancedMetric(m380.rule,value)},
  {...m381, evaluate:(value:number|null)=>evaluateAdvancedMetric(m381.rule,value)},
  {...m382, evaluate:(value:number|null)=>evaluateAdvancedMetric(m382.rule,value)},
  {...m383, evaluate:(value:number|null)=>evaluateAdvancedMetric(m383.rule,value)},
  {...m384, evaluate:(value:number|null)=>evaluateAdvancedMetric(m384.rule,value)},
  {...m385, evaluate:(value:number|null)=>evaluateAdvancedMetric(m385.rule,value)},
  {...m386, evaluate:(value:number|null)=>evaluateAdvancedMetric(m386.rule,value)},
  {...m387, evaluate:(value:number|null)=>evaluateAdvancedMetric(m387.rule,value)},
  {...m388, evaluate:(value:number|null)=>evaluateAdvancedMetric(m388.rule,value)},
  {...m389, evaluate:(value:number|null)=>evaluateAdvancedMetric(m389.rule,value)},
  {...m390, evaluate:(value:number|null)=>evaluateAdvancedMetric(m390.rule,value)},
  {...m391, evaluate:(value:number|null)=>evaluateAdvancedMetric(m391.rule,value)},
  {...m392, evaluate:(value:number|null)=>evaluateAdvancedMetric(m392.rule,value)},
  {...m393, evaluate:(value:number|null)=>evaluateAdvancedMetric(m393.rule,value)},
  {...m394, evaluate:(value:number|null)=>evaluateAdvancedMetric(m394.rule,value)},
  {...m395, evaluate:(value:number|null)=>evaluateAdvancedMetric(m395.rule,value)},
  {...m396, evaluate:(value:number|null)=>evaluateAdvancedMetric(m396.rule,value)},
  {...m397, evaluate:(value:number|null)=>evaluateAdvancedMetric(m397.rule,value)},
  {...m398, evaluate:(value:number|null)=>evaluateAdvancedMetric(m398.rule,value)},
  {...m399, evaluate:(value:number|null)=>evaluateAdvancedMetric(m399.rule,value)},
  {...m400, evaluate:(value:number|null)=>evaluateAdvancedMetric(m400.rule,value)},
] as const;
