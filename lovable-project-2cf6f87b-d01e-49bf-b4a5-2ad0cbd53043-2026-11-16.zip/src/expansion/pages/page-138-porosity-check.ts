import {evaluateFeature} from '../featureEngine';
export const module={id:138,slug:'porosity-check',title:'Porosity check',metric:'porosity',unit:'%',rule:'percent',description:'Checks porosity percentage range.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
