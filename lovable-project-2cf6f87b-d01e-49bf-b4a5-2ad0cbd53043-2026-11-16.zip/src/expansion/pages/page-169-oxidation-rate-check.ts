import {evaluateFeature} from '../featureEngine';
export const module={id:169,slug:'oxidation-rate-check',title:'Oxidation rate check',metric:'oxidation_rate',unit:'kg/m²/s',rule:'nonnegative',description:'Checks non-negative oxidation rate.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
