import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:333,slug:'refractive-index',title:'Refractive index',metric:'refractive_index',unit:'dimensionless',rule:'positive',description:'Checks a supplied refractive index value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
