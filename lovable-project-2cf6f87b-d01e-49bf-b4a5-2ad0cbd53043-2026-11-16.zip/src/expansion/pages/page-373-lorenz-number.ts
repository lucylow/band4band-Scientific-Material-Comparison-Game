import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:373,slug:'lorenz-number',title:'Lorenz number',metric:'lorenz_number',unit:'WΩ/K²',rule:'positive',description:'Checks a supplied lorenz number value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
