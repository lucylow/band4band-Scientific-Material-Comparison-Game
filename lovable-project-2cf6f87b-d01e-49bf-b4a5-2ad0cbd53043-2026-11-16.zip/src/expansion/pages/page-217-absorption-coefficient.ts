import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:217,slug:'absorption-coefficient',title:'Absorption coefficient',metric:'absorption_coefficient',unit:'m⁻¹',rule:'nonnegative',description:'Screens absorption coefficient values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
