import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:253,slug:'sintering-temperature',title:'Sintering temperature',metric:'sinter_temp',unit:'K',rule:'positive',description:'Screens sintering temperature values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
