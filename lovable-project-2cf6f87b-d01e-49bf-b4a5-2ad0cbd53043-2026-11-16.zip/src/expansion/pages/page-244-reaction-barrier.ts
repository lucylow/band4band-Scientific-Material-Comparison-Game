import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:244,slug:'reaction-barrier',title:'Reaction barrier',metric:'reaction_barrier',unit:'eV',rule:'nonnegative',description:'Screens reaction barrier values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
