import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:299,slug:'model-residual',title:'Model residual',metric:'model_residual',unit:'property units',rule:'nonnegative',description:'Screens model residual values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
