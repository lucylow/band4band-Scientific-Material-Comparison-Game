import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:237,slug:'band-alignment-offset',title:'Band alignment offset',metric:'band_offset',unit:'eV',rule:'signed',description:'Screens band alignment offset values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
