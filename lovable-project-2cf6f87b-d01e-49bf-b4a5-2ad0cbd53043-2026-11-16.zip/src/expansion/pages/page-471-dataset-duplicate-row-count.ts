import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:471,slug:'dataset-duplicate-row-count',title:'Dataset Duplicate Row Count',metric:'dataset_duplicate_row_count',unit:'—',rule:'nonnegative',description:'Checks dataset duplicate row count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
