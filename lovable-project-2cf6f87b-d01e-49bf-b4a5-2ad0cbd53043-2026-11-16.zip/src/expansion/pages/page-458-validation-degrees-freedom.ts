import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:458,slug:'validation-degrees-freedom',title:'Validation Degrees Freedom',metric:'validation_degrees_freedom',unit:'—',rule:'nonnegative',description:'Checks validation degrees freedom for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
