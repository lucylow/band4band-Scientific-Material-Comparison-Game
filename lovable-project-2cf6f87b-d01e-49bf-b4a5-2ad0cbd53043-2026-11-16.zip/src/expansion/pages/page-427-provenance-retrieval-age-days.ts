import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:427,slug:'provenance-retrieval-age-days',title:'Provenance Retrieval Age Days',metric:'provenance_retrieval_age_days',unit:'—',rule:'nonnegative',description:'Checks provenance retrieval age days for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
