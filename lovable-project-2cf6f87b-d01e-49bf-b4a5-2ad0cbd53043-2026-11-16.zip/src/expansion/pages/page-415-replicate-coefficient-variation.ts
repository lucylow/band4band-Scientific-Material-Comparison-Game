import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:415,slug:'replicate-coefficient-variation',title:'Replicate Coefficient Variation',metric:'replicate_coefficient_variation',unit:'—',rule:'nonnegative',description:'Checks replicate coefficient variation for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
