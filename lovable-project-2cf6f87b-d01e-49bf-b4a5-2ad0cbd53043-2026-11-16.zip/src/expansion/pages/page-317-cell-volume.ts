import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:317,slug:'cell-volume',title:'Unit-cell volume',metric:'cell_volume',unit:'Å³',rule:'positive',description:'Checks a supplied unit-cell volume value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
