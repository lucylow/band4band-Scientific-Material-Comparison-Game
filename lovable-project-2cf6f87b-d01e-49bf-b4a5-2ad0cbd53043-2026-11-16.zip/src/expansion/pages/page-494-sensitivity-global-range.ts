import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:494,slug:'sensitivity-global-range',title:'Sensitivity Global Range',metric:'sensitivity_global_range',unit:'—',rule:'nonnegative',description:'Checks sensitivity global range for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
