import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:311,slug:'lattice-vector-a',title:'Lattice vector a length',metric:'lattice_a',unit:'Å',rule:'positive',description:'Checks a supplied lattice vector a length value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
