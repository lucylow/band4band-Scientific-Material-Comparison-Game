import {evaluateFeature} from '../featureEngine';
export const module={id:151,slug:'solar-absorption-check',title:'Solar absorption check',metric:'solar_absorption',unit:'%',rule:'percent',description:'Checks absorptance percentage range.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
