import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:469,slug:'model-residual-kurtosis',title:'Model Residual Kurtosis',metric:'model_residual_kurtosis',unit:'—',rule:'signed',description:'Checks model residual kurtosis for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
