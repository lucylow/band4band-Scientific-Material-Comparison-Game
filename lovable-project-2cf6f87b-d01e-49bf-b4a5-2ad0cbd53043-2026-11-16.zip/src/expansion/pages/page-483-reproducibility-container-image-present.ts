import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:483,slug:'reproducibility-container-image-present',title:'Reproducibility Container Image Present',metric:'reproducibility_container_image_present',unit:'—',rule:'fraction',description:'Checks reproducibility container image present for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
