import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:263,slug:'creep-activation-energy',title:'Creep activation energy',metric:'creep_ea',unit:'eV',rule:'nonnegative',description:'Screens creep activation energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
