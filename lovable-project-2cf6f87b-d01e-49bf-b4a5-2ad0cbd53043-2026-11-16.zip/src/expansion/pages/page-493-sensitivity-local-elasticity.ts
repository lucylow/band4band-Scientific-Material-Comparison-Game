import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:493,slug:'sensitivity-local-elasticity',title:'Sensitivity Local Elasticity',metric:'sensitivity_local_elasticity',unit:'—',rule:'signed',description:'Checks sensitivity local elasticity for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
