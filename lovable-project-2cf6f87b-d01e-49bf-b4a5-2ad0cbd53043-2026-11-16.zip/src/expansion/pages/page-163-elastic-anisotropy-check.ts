import {evaluateFeature} from '../featureEngine';
export const module={id:163,slug:'elastic-anisotropy-check',title:'Elastic anisotropy check',metric:'elastic_anisotropy',unit:'1',rule:'positive',description:'Checks positive elastic anisotropy ratio.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
