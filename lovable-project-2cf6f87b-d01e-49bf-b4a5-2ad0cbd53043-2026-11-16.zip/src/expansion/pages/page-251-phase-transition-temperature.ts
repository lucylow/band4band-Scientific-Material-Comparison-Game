import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:251,slug:'phase-transition-temperature',title:'Phase transition temperature',metric:'transition_temp',unit:'K',rule:'positive',description:'Screens phase transition temperature values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
