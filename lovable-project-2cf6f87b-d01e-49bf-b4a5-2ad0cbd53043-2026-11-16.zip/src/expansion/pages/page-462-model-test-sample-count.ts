import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:462,slug:'model-test-sample-count',title:'Model Test Sample Count',metric:'model_test_sample_count',unit:'—',rule:'positive_integer',description:'Checks model test sample count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
