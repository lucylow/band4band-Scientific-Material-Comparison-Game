import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:479,slug:'dataset-source-diversity',title:'Dataset Source Diversity',metric:'dataset_source_diversity',unit:'—',rule:'positive_integer',description:'Checks dataset source diversity for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
