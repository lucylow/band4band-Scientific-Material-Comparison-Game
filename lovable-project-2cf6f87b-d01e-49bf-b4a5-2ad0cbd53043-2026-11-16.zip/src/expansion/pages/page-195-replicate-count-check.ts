import {evaluateFeature} from '../featureEngine';
export const module={id:195,slug:'replicate-count-check',title:'Replicate count check',metric:'replicate_count',unit:'count',rule:'integer',description:'Checks positive replicate count.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
