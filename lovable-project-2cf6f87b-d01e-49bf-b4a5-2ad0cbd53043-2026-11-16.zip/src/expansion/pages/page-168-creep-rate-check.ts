import {evaluateFeature} from '../featureEngine';
export const module={id:168,slug:'creep-rate-check',title:'Creep rate check',metric:'creep_rate',unit:'s⁻¹',rule:'nonnegative',description:'Checks non-negative creep rate.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
