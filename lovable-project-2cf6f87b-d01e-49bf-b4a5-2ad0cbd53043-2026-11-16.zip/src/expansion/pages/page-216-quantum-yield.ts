import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:216,slug:'quantum-yield',title:'Quantum yield',metric:'quantum_yield',unit:'%',rule:'percent',description:'Screens quantum yield values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
