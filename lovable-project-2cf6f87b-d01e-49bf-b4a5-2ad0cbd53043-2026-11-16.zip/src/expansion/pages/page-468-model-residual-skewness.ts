import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:468,slug:'model-residual-skewness',title:'Model Residual Skewness',metric:'model_residual_skewness',unit:'—',rule:'signed',description:'Checks model residual skewness for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
