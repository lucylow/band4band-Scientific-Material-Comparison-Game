import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:434,slug:'method-kpoint-density',title:'Method Kpoint Density',metric:'method_kpoint_density',unit:'—',rule:'positive',description:'Checks method kpoint density for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
