import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:354,slug:'scf-iteration-count',title:'SCF iteration count',metric:'scf_iterations',unit:'iterations',rule:'positive_integer',description:'Checks a supplied scf iteration count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
