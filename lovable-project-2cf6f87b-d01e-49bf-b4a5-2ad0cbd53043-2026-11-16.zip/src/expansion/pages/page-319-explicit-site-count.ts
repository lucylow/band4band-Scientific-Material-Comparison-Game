import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:319,slug:'explicit-site-count',title:'Explicit site count',metric:'site_count',unit:'sites',rule:'positive_integer',description:'Checks a supplied explicit site count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
