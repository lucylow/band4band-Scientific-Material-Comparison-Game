import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:357,slug:'energy-per-atom',title:'Energy per atom',metric:'energy_per_atom',unit:'eV/atom',rule:'signed',description:'Checks a supplied energy per atom value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
