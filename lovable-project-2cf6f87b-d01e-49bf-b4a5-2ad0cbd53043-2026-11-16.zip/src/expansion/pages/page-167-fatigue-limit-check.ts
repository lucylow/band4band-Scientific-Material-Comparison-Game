import {evaluateFeature} from '../featureEngine';
export const module={id:167,slug:'fatigue-limit-check',title:'Fatigue limit check',metric:'fatigue_limit',unit:'MPa',rule:'nonnegative',description:'Checks non-negative fatigue limit.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
