import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:270,slug:'thermal-boundary-resistance',title:'Thermal boundary resistance',metric:'tbr',unit:'m²K/W',rule:'nonnegative',description:'Screens thermal boundary resistance values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
