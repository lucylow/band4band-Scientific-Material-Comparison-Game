import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:305,slug:'valence-band-maximum',title:'Valence band maximum',metric:'vbm',unit:'eV',rule:'signed',description:'Checks a supplied valence band maximum value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
