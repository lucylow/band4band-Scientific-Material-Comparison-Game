import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:330,slug:'thermal-diffusivity',title:'Thermal diffusivity',metric:'thermal_diffusivity',unit:'m²/s',rule:'positive',description:'Checks a supplied thermal diffusivity value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
