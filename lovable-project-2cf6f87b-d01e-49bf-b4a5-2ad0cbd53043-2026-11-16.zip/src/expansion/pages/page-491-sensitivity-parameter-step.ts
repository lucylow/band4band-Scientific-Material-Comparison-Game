import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:491,slug:'sensitivity-parameter-step',title:'Sensitivity Parameter Step',metric:'sensitivity_parameter_step',unit:'—',rule:'positive',description:'Checks sensitivity parameter step for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
