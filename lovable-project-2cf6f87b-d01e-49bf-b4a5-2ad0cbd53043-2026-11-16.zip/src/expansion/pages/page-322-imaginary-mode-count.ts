import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:322,slug:'imaginary-mode-count',title:'Imaginary phonon mode count',metric:'imaginary_modes',unit:'modes',rule:'nonnegative',description:'Checks a supplied imaginary phonon mode count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
