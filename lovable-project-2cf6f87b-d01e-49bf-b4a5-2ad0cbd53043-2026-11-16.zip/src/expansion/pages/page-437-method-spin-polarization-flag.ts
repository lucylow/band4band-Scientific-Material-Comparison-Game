import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:437,slug:'method-spin-polarization-flag',title:'Method Spin Polarization Flag',metric:'method_spin_polarization_flag',unit:'—',rule:'fraction',description:'Checks method spin polarization flag for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
