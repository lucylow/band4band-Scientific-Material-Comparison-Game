import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:350,slug:'adhesion-energy',title:'Adhesion energy',metric:'adhesion_energy',unit:'J/m²',rule:'nonnegative',description:'Checks a supplied adhesion energy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
