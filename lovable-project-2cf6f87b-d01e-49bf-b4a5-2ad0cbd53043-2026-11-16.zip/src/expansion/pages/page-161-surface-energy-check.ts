import {evaluateFeature} from '../featureEngine';
export const module={id:161,slug:'surface-energy-check',title:'Surface energy check',metric:'surface_energy',unit:'J/m²',rule:'nonnegative',description:'Checks non-negative surface energy.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
