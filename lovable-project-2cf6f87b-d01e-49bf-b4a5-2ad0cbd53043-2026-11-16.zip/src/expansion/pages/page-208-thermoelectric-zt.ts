import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:208,slug:'thermoelectric-zt',title:'Thermoelectric figure of merit',metric:'zt',unit:'dimensionless',rule:'nonnegative',description:'Screens thermoelectric figure of merit values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
