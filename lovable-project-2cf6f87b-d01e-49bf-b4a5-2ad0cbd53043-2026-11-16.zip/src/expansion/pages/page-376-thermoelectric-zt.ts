import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:376,slug:'thermoelectric-zt',title:'Thermoelectric ZT',metric:'zt',unit:'dimensionless',rule:'nonnegative',description:'Checks a supplied thermoelectric zt value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
