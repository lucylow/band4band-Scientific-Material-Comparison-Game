import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:401,slug:'uncertainty-input-count',title:'Uncertainty Input Count',metric:'uncertainty_input_count',unit:'—',rule:'positive_integer',description:'Checks uncertainty input count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
