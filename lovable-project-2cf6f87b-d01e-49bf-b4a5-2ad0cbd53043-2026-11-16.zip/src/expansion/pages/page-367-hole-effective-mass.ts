import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:367,slug:'hole-effective-mass',title:'Hole effective mass',metric:'hole_mass',unit:'mₑ',rule:'positive',description:'Checks a supplied hole effective mass value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
