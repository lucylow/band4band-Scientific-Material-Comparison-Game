import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:498,slug:'sensitivity-scenario-count',title:'Sensitivity Scenario Count',metric:'sensitivity_scenario_count',unit:'—',rule:'positive_integer',description:'Checks sensitivity scenario count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
