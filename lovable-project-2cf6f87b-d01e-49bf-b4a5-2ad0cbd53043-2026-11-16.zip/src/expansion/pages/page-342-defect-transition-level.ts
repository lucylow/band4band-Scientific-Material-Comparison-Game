import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:342,slug:'defect-transition-level',title:'Defect transition level',metric:'defect_transition',unit:'eV',rule:'signed',description:'Checks a supplied defect transition level value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
