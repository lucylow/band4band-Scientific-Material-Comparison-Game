import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:500,slug:'sensitivity-stability-index',title:'Sensitivity Stability Index',metric:'sensitivity_stability_index',unit:'—',rule:'fraction',description:'Checks sensitivity stability index for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
