import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:445,slug:'experimental-crystal-orientation',title:'Experimental Crystal Orientation',metric:'experimental_crystal_orientation',unit:'—',rule:'angle',description:'Checks experimental crystal orientation for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
