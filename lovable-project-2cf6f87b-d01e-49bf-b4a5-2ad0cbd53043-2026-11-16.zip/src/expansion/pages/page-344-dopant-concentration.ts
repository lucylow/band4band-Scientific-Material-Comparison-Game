import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:344,slug:'dopant-concentration',title:'Dopant concentration',metric:'dopant_concentration',unit:'cm⁻³',rule:'nonnegative',description:'Checks a supplied dopant concentration value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
