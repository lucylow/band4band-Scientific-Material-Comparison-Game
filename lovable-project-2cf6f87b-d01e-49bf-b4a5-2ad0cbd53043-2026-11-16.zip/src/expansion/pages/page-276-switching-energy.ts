import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:276,slug:'switching-energy',title:'Switching energy',metric:'switching_energy',unit:'J',rule:'nonnegative',description:'Screens switching energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
