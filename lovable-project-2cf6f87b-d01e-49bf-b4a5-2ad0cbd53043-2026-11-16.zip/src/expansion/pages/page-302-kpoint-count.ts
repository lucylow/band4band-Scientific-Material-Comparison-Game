import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:302,slug:'kpoint-count',title:'K-point count',metric:'kpoint_count',unit:'points',rule:'positive_integer',description:'Checks a supplied k-point count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
