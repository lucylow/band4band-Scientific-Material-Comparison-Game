import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:258,slug:'fracture-energy',title:'Fracture energy',metric:'fracture_energy',unit:'J/m²',rule:'nonnegative',description:'Screens fracture energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
