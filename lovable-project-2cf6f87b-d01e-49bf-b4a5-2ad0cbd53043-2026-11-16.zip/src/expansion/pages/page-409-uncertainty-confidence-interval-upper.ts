import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:409,slug:'uncertainty-confidence-interval-upper',title:'Uncertainty Confidence Interval Upper',metric:'uncertainty_confidence_interval_upper',unit:'—',rule:'signed',description:'Checks uncertainty confidence interval upper for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
