import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:351,slug:'calculation-convergence',title:'Calculation convergence residual',metric:'convergence_residual',unit:'eV/atom',rule:'nonnegative',description:'Checks a supplied calculation convergence residual value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
