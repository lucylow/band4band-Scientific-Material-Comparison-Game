import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:418,slug:'replicate-between-lab-spread',title:'Replicate Between Lab Spread',metric:'replicate_between_lab_spread',unit:'—',rule:'nonnegative',description:'Checks replicate between lab spread for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
