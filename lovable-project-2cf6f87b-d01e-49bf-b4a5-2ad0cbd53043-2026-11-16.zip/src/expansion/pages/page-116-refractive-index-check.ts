import {evaluateFeature} from '../featureEngine';
export const module={id:116,slug:'refractive-index-check',title:'Refractive index check',metric:'refractive_index',unit:'1',rule:'positive',description:'Validates positive refractive index.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
