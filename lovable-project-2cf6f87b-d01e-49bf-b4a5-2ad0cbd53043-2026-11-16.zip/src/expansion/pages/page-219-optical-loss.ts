import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:219,slug:'optical-loss',title:'Optical loss',metric:'optical_loss',unit:'dB',rule:'nonnegative',description:'Screens optical loss values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
