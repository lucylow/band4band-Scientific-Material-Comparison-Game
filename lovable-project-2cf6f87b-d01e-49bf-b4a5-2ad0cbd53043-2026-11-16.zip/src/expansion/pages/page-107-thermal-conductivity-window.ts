import {evaluateFeature} from '../featureEngine';
export const module={id:107,slug:'thermal-conductivity-window',title:'Thermal conductivity window',metric:'thermal_conductivity',unit:'W/(m·K)',rule:'higher',description:'Flags high thermal conductivity records.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
