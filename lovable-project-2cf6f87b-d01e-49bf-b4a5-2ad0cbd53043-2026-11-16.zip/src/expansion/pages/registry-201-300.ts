import type {FeatureResult} from '../featureEngine';
import {evaluateAdvancedMetric} from '../advancedEngine';
import {module as m201} from './page-201-phonon-density-of-states';
import {module as m202} from './page-202-phonon-group-velocity';
import {module as m203} from './page-203-sound-velocity';
import {module as m204} from './page-204-lattice-thermal-resistivity';
import {module as m205} from './page-205-electronic-thermal-conductivity';
import {module as m206} from './page-206-lorenz-number';
import {module as m207} from './page-207-power-factor';
import {module as m208} from './page-208-thermoelectric-zt';
import {module as m209} from './page-209-seebeck-sign';
import {module as m210} from './page-210-hall-coefficient';
import {module as m211} from './page-211-hall-mobility';
import {module as m212} from './page-212-carrier-lifetime';
import {module as m213} from './page-213-diffusion-length';
import {module as m214} from './page-214-recombination-rate';
import {module as m215} from './page-215-radiative-efficiency';
import {module as m216} from './page-216-quantum-yield';
import {module as m217} from './page-217-absorption-coefficient';
import {module as m218} from './page-218-extinction-coefficient';
import {module as m219} from './page-219-optical-loss';
import {module as m220} from './page-220-photoluminescence-peak';
import {module as m221} from './page-221-raman-shift';
import {module as m222} from './page-222-exciton-radius';
import {module as m223} from './page-223-exciton-binding-energy';
import {module as m224} from './page-224-work-function-spread';
import {module as m225} from './page-225-surface-dipole';
import {module as m226} from './page-226-vacancy-formation-energy';
import {module as m227} from './page-227-interstitial-formation-energy';
import {module as m228} from './page-228-substitution-energy';
import {module as m229} from './page-229-migration-barrier';
import {module as m230} from './page-230-diffusion-coefficient';
import {module as m231} from './page-231-defect-charge-state';
import {module as m232} from './page-232-defect-transition-level';
import {module as m233} from './page-233-dopant-solubility';
import {module as m234} from './page-234-dopant-activation';
import {module as m235} from './page-235-carrier-compensation';
import {module as m236} from './page-236-fermi-level-offset';
import {module as m237} from './page-237-band-alignment-offset';
import {module as m238} from './page-238-interface-dipole';
import {module as m239} from './page-239-interface-state-density';
import {module as m240} from './page-240-grain-boundary-energy';
import {module as m241} from './page-241-surface-reconstruction-energy';
import {module as m242} from './page-242-adsorption-energy';
import {module as m243} from './page-243-binding-energy';
import {module as m244} from './page-244-reaction-barrier';
import {module as m245} from './page-245-catalytic-turnover-frequency';
import {module as m246} from './page-246-electrochemical-overpotential';
import {module as m247} from './page-247-exchange-current-density';
import {module as m248} from './page-248-corrosion-potential';
import {module as m249} from './page-249-corrosion-current-density';
import {module as m250} from './page-250-oxidation-activation-energy';
import {module as m251} from './page-251-phase-transition-temperature';
import {module as m252} from './page-252-glass-transition-temperature';
import {module as m253} from './page-253-sintering-temperature';
import {module as m254} from './page-254-sintering-shrinkage';
import {module as m255} from './page-255-grain-size-distribution';
import {module as m256} from './page-256-pore-fraction';
import {module as m257} from './page-257-bulk-density-ratio';
import {module as m258} from './page-258-fracture-energy';
import {module as m259} from './page-259-critical-stress-intensity';
import {module as m260} from './page-260-elastic-anisotropy-index';
import {module as m261} from './page-261-thermal-shock-parameter';
import {module as m262} from './page-262-thermal-cycle-count';
import {module as m263} from './page-263-creep-activation-energy';
import {module as m264} from './page-264-fatigue-cycle-count';
import {module as m265} from './page-265-wear-rate';
import {module as m266} from './page-266-friction-coefficient';
import {module as m267} from './page-267-contact-angle';
import {module as m268} from './page-268-surface-tension';
import {module as m269} from './page-269-adhesion-strength';
import {module as m270} from './page-270-thermal-boundary-resistance';
import {module as m271} from './page-271-electrical-contact-resistivity';
import {module as m272} from './page-272-dielectric-loss-tangent';
import {module as m273} from './page-273-breakdown-probability';
import {module as m274} from './page-274-leakage-density';
import {module as m275} from './page-275-switching-frequency';
import {module as m276} from './page-276-switching-energy';
import {module as m277} from './page-277-gate-charge';
import {module as m278} from './page-278-threshold-voltage';
import {module as m279} from './page-279-on-state-resistance';
import {module as m280} from './page-280-device-thermal-resistance';
import {module as m281} from './page-281-junction-temperature';
import {module as m282} from './page-282-radiation-displacement-dose';
import {module as m283} from './page-283-ionizing-dose';
import {module as m284} from './page-284-neutron-cross-section';
import {module as m285} from './page-285-critical-element-fraction';
import {module as m286} from './page-286-recycled-content';
import {module as m287} from './page-287-recovery-yield';
import {module as m288} from './page-288-embodied-energy';
import {module as m289} from './page-289-water-footprint';
import {module as m290} from './page-290-process-yield';
import {module as m291} from './page-291-batch-variation';
import {module as m292} from './page-292-measurement-repeatability';
import {module as m293} from './page-293-measurement-reproducibility';
import {module as m294} from './page-294-confidence-interval-width';
import {module as m295} from './page-295-relative-uncertainty';
import {module as m296} from './page-296-sample-count';
import {module as m297} from './page-297-data-age-days';
import {module as m298} from './page-298-replica-agreement';
import {module as m299} from './page-299-model-residual';
import {module as m300} from './page-300-fit-r-squared';

export const ADVANCED_MODULES = [
  {...m201, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m201.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m202, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m202.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m203, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m203.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m204, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m204.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m205, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m205.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m206, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m206.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m207, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m207.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m208, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m208.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m209, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m209.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m210, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m210.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m211, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m211.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m212, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m212.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m213, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m213.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m214, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m214.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m215, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m215.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m216, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m216.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m217, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m217.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m218, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m218.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m219, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m219.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m220, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m220.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m221, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m221.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m222, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m222.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m223, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m223.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m224, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m224.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m225, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m225.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m226, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m226.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m227, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m227.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m228, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m228.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m229, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m229.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m230, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m230.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m231, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m231.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m232, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m232.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m233, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m233.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m234, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m234.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m235, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m235.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m236, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m236.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m237, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m237.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m238, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m238.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m239, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m239.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m240, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m240.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m241, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m241.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m242, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m242.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m243, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m243.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m244, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m244.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m245, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m245.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m246, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m246.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m247, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m247.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m248, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m248.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m249, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m249.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m250, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m250.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m251, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m251.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m252, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m252.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m253, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m253.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m254, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m254.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m255, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m255.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m256, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m256.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m257, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m257.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m258, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m258.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m259, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m259.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m260, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m260.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m261, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m261.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m262, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m262.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m263, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m263.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m264, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m264.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m265, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m265.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m266, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m266.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m267, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m267.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m268, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m268.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m269, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m269.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m270, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m270.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m271, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m271.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m272, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m272.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m273, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m273.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m274, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m274.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m275, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m275.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m276, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m276.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m277, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m277.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m278, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m278.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m279, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m279.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m280, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m280.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m281, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m281.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m282, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m282.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m283, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m283.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m284, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m284.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m285, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m285.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m286, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m286.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m287, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m287.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m288, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m288.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m289, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m289.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m290, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m290.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m291, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m291.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m292, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m292.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m293, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m293.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m294, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m294.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m295, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m295.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m296, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m296.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m297, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m297.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m298, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m298.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m299, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m299.rule,typeof value==='number'?value:value===null?null:value?1:0)},
  {...m300, evaluate:(value:number|boolean|null):FeatureResult=>evaluateAdvancedMetric(m300.rule,typeof value==='number'?value:value===null?null:value?1:0)},
] as const;
