import {evaluateFeature} from '../featureEngine';
export const module={id:141,slug:'dos-at-fermi-check',title:'DOS at Fermi check',metric:'dos_at_fermi',unit:'states/eV',rule:'nonnegative',description:'Checks non-negative density of states at Fermi level.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
