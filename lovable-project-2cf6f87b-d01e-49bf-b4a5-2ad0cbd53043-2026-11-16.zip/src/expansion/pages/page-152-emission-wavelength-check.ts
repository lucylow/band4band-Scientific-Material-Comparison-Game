import {evaluateFeature} from '../featureEngine';
export const module={id:152,slug:'emission-wavelength-check',title:'Emission wavelength check',metric:'emission_wavelength',unit:'nm',rule:'positive',description:'Checks positive optical wavelength.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
