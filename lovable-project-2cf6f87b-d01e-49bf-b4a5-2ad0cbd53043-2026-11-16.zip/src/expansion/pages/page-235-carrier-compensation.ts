import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:235,slug:'carrier-compensation',title:'Carrier compensation ratio',metric:'carrier_compensation',unit:'%',rule:'percent',description:'Screens carrier compensation ratio values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
