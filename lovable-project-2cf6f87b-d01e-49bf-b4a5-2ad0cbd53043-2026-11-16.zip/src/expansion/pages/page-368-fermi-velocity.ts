import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:368,slug:'fermi-velocity',title:'Fermi velocity',metric:'fermi_velocity',unit:'m/s',rule:'positive',description:'Checks a supplied fermi velocity value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
