import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:206,slug:'lorenz-number',title:'Lorenz number',metric:'lorenz_number',unit:'W·Ω/K²',rule:'positive',description:'Screens lorenz number values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
