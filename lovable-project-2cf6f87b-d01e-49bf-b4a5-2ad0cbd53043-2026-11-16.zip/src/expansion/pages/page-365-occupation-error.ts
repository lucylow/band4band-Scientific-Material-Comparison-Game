import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:365,slug:'occupation-error',title:'Occupation sum error',metric:'occupation_error',unit:'%',rule:'nonnegative',description:'Checks a supplied occupation sum error value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
