import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:405,slug:'uncertainty-covariance-term',title:'Uncertainty Covariance Term',metric:'uncertainty_covariance_term',unit:'—',rule:'signed',description:'Checks uncertainty covariance term for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
