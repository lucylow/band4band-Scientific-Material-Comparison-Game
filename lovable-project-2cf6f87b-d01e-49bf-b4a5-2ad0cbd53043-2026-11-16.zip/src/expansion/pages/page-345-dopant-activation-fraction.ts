import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:345,slug:'dopant-activation-fraction',title:'Dopant activation fraction',metric:'dopant_activation',unit:'fraction',rule:'fraction',description:'Checks a supplied dopant activation fraction value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
