import {evaluateFeature} from '../featureEngine';
export const module={id:120,slug:'fermi-energy-check',title:'Fermi energy check',metric:'fermi_energy',unit:'eV',rule:'finite',description:'Checks finite Fermi energy records.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
