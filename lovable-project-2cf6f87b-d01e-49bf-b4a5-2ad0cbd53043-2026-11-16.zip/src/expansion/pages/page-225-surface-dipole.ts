import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:225,slug:'surface-dipole',title:'Surface dipole',metric:'surface_dipole',unit:'D',rule:'signed',description:'Screens surface dipole values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
