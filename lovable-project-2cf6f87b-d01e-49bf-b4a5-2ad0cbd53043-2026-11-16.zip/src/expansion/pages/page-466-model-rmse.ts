import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:466,slug:'model-rmse',title:'Model Rmse',metric:'model_rmse',unit:'—',rule:'nonnegative',description:'Checks model rmse for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
