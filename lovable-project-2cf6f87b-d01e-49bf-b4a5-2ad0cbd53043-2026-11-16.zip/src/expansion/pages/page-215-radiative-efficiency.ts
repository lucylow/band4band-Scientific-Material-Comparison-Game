import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:215,slug:'radiative-efficiency',title:'Radiative efficiency',metric:'radiative_efficiency',unit:'%',rule:'percent',description:'Screens radiative efficiency values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
