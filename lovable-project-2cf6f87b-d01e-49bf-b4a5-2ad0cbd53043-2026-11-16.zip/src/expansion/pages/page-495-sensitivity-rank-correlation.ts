import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:495,slug:'sensitivity-rank-correlation',title:'Sensitivity Rank Correlation',metric:'sensitivity_rank_correlation',unit:'—',rule:'signed',description:'Checks sensitivity rank correlation for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
