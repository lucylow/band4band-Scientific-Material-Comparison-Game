import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:347,slug:'diffusion-coefficient',title:'Diffusion coefficient',metric:'diffusion_coefficient',unit:'m²/s',rule:'nonnegative',description:'Checks a supplied diffusion coefficient value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
