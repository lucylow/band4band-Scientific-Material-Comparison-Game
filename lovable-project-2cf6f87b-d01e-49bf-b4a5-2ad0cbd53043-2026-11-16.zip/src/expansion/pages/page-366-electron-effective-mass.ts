import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:366,slug:'electron-effective-mass',title:'Electron effective mass',metric:'electron_mass',unit:'mₑ',rule:'positive',description:'Checks a supplied electron effective mass value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
