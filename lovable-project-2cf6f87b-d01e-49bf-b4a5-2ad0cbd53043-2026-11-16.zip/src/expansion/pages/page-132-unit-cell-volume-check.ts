import {evaluateFeature} from '../featureEngine';
export const module={id:132,slug:'unit-cell-volume-check',title:'Unit cell volume check',metric:'unit_cell_volume',unit:'Å³',rule:'positive',description:'Validates positive unit-cell volume.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
