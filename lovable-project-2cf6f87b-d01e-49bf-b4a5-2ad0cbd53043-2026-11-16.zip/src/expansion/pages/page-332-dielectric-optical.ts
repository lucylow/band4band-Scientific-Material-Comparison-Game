import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:332,slug:'dielectric-optical',title:'Optical dielectric constant',metric:'dielectric_optical',unit:'dimensionless',rule:'positive',description:'Checks a supplied optical dielectric constant value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
