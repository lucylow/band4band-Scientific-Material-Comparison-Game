import {evaluateFeature} from '../featureEngine';
export const module={id:127,slug:'lattice-b-check',title:'Lattice b check',metric:'lattice_b',unit:'Å',rule:'positive',description:'Validates positive lattice parameter b.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
