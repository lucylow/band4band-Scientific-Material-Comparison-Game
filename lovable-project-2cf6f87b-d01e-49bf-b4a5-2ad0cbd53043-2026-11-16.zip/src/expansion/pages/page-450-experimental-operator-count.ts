import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:450,slug:'experimental-operator-count',title:'Experimental Operator Count',metric:'experimental_operator_count',unit:'—',rule:'positive_integer',description:'Checks experimental operator count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
