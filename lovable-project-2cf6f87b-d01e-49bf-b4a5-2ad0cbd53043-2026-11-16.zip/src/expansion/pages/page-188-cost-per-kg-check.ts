import {evaluateFeature} from '../featureEngine';
export const module={id:188,slug:'cost-per-kg-check',title:'Material cost check',metric:'cost_per_kg',unit:'USD/kg',rule:'positive',description:'Checks positive quoted material cost.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
