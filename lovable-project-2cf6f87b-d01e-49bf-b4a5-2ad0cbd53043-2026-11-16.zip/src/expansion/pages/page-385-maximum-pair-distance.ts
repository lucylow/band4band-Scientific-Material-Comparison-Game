import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:385,slug:'maximum-pair-distance',title:'Maximum pair distance',metric:'maximum_distance',unit:'Å',rule:'positive',description:'Checks a supplied maximum pair distance value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
