import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:315,slug:'lattice-angle-beta',title:'Lattice angle beta',metric:'beta',unit:'degrees',rule:'angle',description:'Checks a supplied lattice angle beta value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
