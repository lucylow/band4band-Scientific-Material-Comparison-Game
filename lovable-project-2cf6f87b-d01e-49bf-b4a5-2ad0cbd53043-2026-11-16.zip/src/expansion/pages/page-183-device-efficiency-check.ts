import {evaluateFeature} from '../featureEngine';
export const module={id:183,slug:'device-efficiency-check',title:'Device efficiency check',metric:'efficiency',unit:'%',rule:'percent',description:'Checks efficiency percentage range.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
