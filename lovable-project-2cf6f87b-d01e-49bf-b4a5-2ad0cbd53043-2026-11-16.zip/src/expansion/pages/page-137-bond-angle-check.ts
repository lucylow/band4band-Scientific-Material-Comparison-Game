import {evaluateFeature} from '../featureEngine';
export const module={id:137,slug:'bond-angle-check',title:'Bond angle check',metric:'bond_angle',unit:'degree',rule:'angle',description:'Checks bond angle range.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
