import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:262,slug:'thermal-cycle-count',title:'Thermal cycle count',metric:'thermal_cycles',unit:'cycles',rule:'integer',description:'Screens thermal cycle count values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
