import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:423,slug:'provenance-source-url-present',title:'Provenance Source Url Present',metric:'provenance_source_url_present',unit:'—',rule:'fraction',description:'Checks provenance source url present for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
