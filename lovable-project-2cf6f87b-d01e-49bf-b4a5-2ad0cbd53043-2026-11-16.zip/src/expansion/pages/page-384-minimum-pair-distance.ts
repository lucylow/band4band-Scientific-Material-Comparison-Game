import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:384,slug:'minimum-pair-distance',title:'Minimum pair distance',metric:'minimum_distance',unit:'Å',rule:'positive',description:'Checks a supplied minimum pair distance value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
