import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:271,slug:'electrical-contact-resistivity',title:'Specific contact resistivity',metric:'contact_resistivity',unit:'Ω·cm²',rule:'nonnegative',description:'Screens specific contact resistivity values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
