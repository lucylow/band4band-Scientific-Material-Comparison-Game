import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:439,slug:'method-temperature-condition',title:'Method Temperature Condition',metric:'method_temperature_condition',unit:'—',rule:'positive',description:'Checks method temperature condition for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
