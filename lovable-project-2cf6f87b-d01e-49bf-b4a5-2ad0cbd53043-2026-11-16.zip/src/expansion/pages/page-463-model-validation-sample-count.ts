import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:463,slug:'model-validation-sample-count',title:'Model Validation Sample Count',metric:'model_validation_sample_count',unit:'—',rule:'positive_integer',description:'Checks model validation sample count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
