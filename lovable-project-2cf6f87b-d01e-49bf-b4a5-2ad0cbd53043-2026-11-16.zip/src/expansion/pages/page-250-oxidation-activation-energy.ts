import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:250,slug:'oxidation-activation-energy',title:'Oxidation activation energy',metric:'oxidation_ea',unit:'eV',rule:'nonnegative',description:'Screens oxidation activation energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
