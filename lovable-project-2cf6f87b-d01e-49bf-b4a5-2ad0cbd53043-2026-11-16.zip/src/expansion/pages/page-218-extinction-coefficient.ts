import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:218,slug:'extinction-coefficient',title:'Extinction coefficient',metric:'extinction_coefficient',unit:'dimensionless',rule:'nonnegative',description:'Screens extinction coefficient values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
