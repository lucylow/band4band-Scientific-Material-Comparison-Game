import {evaluateFeature} from '../featureEngine';
export const module={id:125,slug:'breakdown-field-check',title:'Breakdown field check',metric:'breakdown_field',unit:'MV/cm',rule:'positive',description:'Validates positive breakdown field values.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
