import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:440,slug:'method-pressure-condition',title:'Method Pressure Condition',metric:'method_pressure_condition',unit:'—',rule:'nonnegative',description:'Checks method pressure condition for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
