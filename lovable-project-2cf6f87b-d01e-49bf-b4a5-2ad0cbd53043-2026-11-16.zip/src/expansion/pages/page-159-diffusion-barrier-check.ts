import {evaluateFeature} from '../featureEngine';
export const module={id:159,slug:'diffusion-barrier-check',title:'Diffusion barrier check',metric:'diffusion_barrier',unit:'eV',rule:'nonnegative',description:'Checks non-negative diffusion barrier.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
