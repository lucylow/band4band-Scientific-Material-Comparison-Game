import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:472,slug:'dataset-missing-value-percent',title:'Dataset Missing Value Percent',metric:'dataset_missing_value_percent',unit:'—',rule:'percent',description:'Checks dataset missing value percent for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
