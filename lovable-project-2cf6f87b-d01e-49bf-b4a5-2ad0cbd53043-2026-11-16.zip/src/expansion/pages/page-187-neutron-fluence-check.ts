import {evaluateFeature} from '../featureEngine';
export const module={id:187,slug:'neutron-fluence-check',title:'Neutron fluence check',metric:'neutron_fluence',unit:'n/cm²',rule:'nonnegative',description:'Checks non-negative neutron fluence.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
