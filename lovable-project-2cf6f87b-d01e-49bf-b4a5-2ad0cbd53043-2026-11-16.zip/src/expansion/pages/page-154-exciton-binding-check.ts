import {evaluateFeature} from '../featureEngine';
export const module={id:154,slug:'exciton-binding-check',title:'Exciton binding check',metric:'exciton_binding_energy',unit:'eV',rule:'nonnegative',description:'Checks non-negative exciton binding energy.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
