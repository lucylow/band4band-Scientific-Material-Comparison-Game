import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:438,slug:'method-dispersion-correction-flag',title:'Method Dispersion Correction Flag',metric:'method_dispersion_correction_flag',unit:'—',rule:'fraction',description:'Checks method dispersion correction flag for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
