import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:247,slug:'exchange-current-density',title:'Exchange current density',metric:'exchange_current',unit:'A/m²',rule:'nonnegative',description:'Screens exchange current density values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
