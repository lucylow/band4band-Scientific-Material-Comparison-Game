import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:202,slug:'phonon-group-velocity',title:'Phonon group velocity',metric:'phonon_velocity',unit:'m/s',rule:'nonnegative',description:'Screens phonon group velocity values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
