import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:279,slug:'on-state-resistance',title:'On-state resistance',metric:'ron',unit:'Ω',rule:'nonnegative',description:'Screens on-state resistance values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
