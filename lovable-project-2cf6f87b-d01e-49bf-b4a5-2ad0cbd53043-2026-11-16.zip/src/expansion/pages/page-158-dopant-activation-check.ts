import {evaluateFeature} from '../featureEngine';
export const module={id:158,slug:'dopant-activation-check',title:'Dopant activation check',metric:'activation_energy',unit:'eV',rule:'nonnegative',description:'Checks non-negative dopant activation energy.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
