import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:484,slug:'reproducibility-seed-recorded',title:'Reproducibility Seed Recorded',metric:'reproducibility_seed_recorded',unit:'—',rule:'fraction',description:'Checks reproducibility seed recorded for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
