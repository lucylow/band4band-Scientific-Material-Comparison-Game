import {evaluateFeature} from '../featureEngine';
export const module={id:153,slug:'band-edge-check',title:'Band edge alignment',metric:'band_edge_offset',unit:'eV',rule:'finite',description:'Checks finite band-edge offset.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
