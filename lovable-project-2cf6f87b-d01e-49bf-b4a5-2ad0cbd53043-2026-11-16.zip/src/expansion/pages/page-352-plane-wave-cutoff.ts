import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:352,slug:'plane-wave-cutoff',title:'Plane-wave cutoff',metric:'ecut',unit:'Ry',rule:'positive',description:'Checks a supplied plane-wave cutoff value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
