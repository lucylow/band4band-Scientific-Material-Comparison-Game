import {evaluateFeature} from '../featureEngine';
export const module={id:123,slug:'carrier-mobility-check',title:'Carrier mobility check',metric:'mobility',unit:'cm²/(V·s)',rule:'positive',description:'Validates positive carrier mobility.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
