import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:300,slug:'fit-r-squared',title:'Fit coefficient of determination',metric:'fit_r2',unit:'dimensionless',rule:'fraction',description:'Screens fit coefficient of determination values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
