import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:221,slug:'raman-shift',title:'Raman shift',metric:'raman_shift',unit:'cm⁻¹',rule:'nonnegative',description:'Screens raman shift values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
