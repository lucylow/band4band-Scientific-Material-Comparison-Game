import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:257,slug:'bulk-density-ratio',title:'Relative bulk density',metric:'relative_density',unit:'%',rule:'percent',description:'Screens relative bulk density values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
