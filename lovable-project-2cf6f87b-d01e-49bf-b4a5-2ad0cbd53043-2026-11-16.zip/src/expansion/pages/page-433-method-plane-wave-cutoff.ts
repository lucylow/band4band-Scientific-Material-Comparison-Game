import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:433,slug:'method-plane-wave-cutoff',title:'Method Plane Wave Cutoff',metric:'method_plane_wave_cutoff',unit:'—',rule:'positive',description:'Checks method plane wave cutoff for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
