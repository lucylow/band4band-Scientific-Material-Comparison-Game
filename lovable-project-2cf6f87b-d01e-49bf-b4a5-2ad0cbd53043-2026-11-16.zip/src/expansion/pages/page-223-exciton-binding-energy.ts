import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:223,slug:'exciton-binding-energy',title:'Exciton binding energy',metric:'exciton_binding',unit:'eV',rule:'nonnegative',description:'Screens exciton binding energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
