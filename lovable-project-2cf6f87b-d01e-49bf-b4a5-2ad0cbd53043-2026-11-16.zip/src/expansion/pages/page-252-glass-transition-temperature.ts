import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:252,slug:'glass-transition-temperature',title:'Glass transition temperature',metric:'glass_temp',unit:'K',rule:'positive',description:'Screens glass transition temperature values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
