import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:390,slug:'symmetry-multiplicity',title:'Symmetry multiplicity',metric:'symmetry_multiplicity',unit:'count',rule:'positive_integer',description:'Checks a supplied symmetry multiplicity value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
