import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:287,slug:'recovery-yield',title:'Material recovery yield',metric:'recovery_yield',unit:'%',rule:'percent',description:'Screens material recovery yield values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
