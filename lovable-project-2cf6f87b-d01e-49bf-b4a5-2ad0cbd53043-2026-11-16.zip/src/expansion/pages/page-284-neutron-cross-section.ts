import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:284,slug:'neutron-cross-section',title:'Neutron cross section',metric:'neutron_cross_section',unit:'barn',rule:'nonnegative',description:'Screens neutron cross section values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
