import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:283,slug:'ionizing-dose',title:'Ionizing radiation dose',metric:'tid',unit:'Gy',rule:'nonnegative',description:'Screens ionizing radiation dose values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
