import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:229,slug:'migration-barrier',title:'Migration barrier',metric:'migration_barrier',unit:'eV',rule:'nonnegative',description:'Screens migration barrier values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
