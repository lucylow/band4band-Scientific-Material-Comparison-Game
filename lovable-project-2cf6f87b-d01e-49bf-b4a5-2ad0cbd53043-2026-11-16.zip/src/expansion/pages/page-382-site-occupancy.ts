import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:382,slug:'site-occupancy',title:'Site occupancy',metric:'occupancy',unit:'fraction',rule:'fraction',description:'Checks a supplied site occupancy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
