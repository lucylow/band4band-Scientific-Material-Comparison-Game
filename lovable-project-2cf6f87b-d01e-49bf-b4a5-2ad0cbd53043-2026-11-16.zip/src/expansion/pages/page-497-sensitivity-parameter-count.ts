import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:497,slug:'sensitivity-parameter-count',title:'Sensitivity Parameter Count',metric:'sensitivity_parameter_count',unit:'—',rule:'positive_integer',description:'Checks sensitivity parameter count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
