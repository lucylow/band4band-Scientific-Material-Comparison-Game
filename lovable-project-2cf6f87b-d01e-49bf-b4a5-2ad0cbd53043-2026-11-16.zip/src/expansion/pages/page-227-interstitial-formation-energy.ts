import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:227,slug:'interstitial-formation-energy',title:'Interstitial formation energy',metric:'interstitial_formation',unit:'eV',rule:'signed',description:'Screens interstitial formation energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
