import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:402,slug:'uncertainty-standard-deviation',title:'Uncertainty Standard Deviation',metric:'uncertainty_standard_deviation',unit:'—',rule:'nonnegative',description:'Checks uncertainty standard deviation for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
