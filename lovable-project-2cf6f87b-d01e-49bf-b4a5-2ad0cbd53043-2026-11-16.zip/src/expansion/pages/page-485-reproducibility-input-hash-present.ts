import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:485,slug:'reproducibility-input-hash-present',title:'Reproducibility Input Hash Present',metric:'reproducibility_input_hash_present',unit:'—',rule:'fraction',description:'Checks reproducibility input hash present for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
