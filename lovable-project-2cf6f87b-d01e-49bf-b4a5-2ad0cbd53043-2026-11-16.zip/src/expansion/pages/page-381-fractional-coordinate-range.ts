import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:381,slug:'fractional-coordinate-range',title:'Fractional coordinate range',metric:'fractional_range',unit:'fraction',rule:'fraction',description:'Checks a supplied fractional coordinate range value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
