import {evaluateFeature} from '../featureEngine';
export const module={id:160,slug:'interface-energy-check',title:'Interface energy check',metric:'interface_energy',unit:'J/m²',rule:'nonnegative',description:'Checks non-negative interface energy.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
