import {evaluateFeature} from '../featureEngine';
export const module={id:121,slug:'electron-affinity-check',title:'Electron affinity check',metric:'electron_affinity',unit:'eV',rule:'finite',description:'Checks finite electron affinity records.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
