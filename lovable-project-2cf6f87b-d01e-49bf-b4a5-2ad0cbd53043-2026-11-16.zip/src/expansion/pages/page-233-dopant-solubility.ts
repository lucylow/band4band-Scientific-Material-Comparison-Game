import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:233,slug:'dopant-solubility',title:'Dopant solubility',metric:'dopant_solubility',unit:'at.%',rule:'percent',description:'Screens dopant solubility values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
