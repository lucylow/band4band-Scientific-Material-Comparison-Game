import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:277,slug:'gate-charge',title:'Gate charge',metric:'gate_charge',unit:'C',rule:'nonnegative',description:'Screens gate charge values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
