import {evaluateFeature} from '../featureEngine';
export const module={id:144,slug:'debye-temperature-check',title:'Debye temperature check',metric:'debye_temperature',unit:'K',rule:'positive',description:'Checks positive Debye temperature.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
