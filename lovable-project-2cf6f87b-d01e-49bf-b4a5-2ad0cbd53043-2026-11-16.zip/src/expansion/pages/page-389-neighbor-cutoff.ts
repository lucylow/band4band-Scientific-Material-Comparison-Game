import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:389,slug:'neighbor-cutoff',title:'Neighbor cutoff',metric:'neighbor_cutoff',unit:'Å',rule:'positive',description:'Checks a supplied neighbor cutoff value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
