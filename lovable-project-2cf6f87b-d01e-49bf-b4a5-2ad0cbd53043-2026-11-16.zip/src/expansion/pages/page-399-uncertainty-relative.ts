import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:399,slug:'uncertainty-relative',title:'Relative uncertainty',metric:'relative_uncertainty',unit:'%',rule:'percent',description:'Checks a supplied relative uncertainty value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
