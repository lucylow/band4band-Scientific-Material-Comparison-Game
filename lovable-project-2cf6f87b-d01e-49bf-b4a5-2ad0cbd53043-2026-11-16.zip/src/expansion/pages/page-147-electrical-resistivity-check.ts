import {evaluateFeature} from '../featureEngine';
export const module={id:147,slug:'electrical-resistivity-check',title:'Electrical resistivity check',metric:'resistivity',unit:'Ω·m',rule:'positive',description:'Checks positive electrical resistivity.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
