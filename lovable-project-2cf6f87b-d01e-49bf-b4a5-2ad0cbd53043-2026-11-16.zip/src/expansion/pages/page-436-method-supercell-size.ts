import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:436,slug:'method-supercell-size',title:'Method Supercell Size',metric:'method_supercell_size',unit:'—',rule:'positive_integer',description:'Checks method supercell size for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
