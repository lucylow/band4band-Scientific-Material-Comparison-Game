import {evaluateFeature} from '../featureEngine';
export const module={id:179,slug:'contact-resistance-check',title:'Contact resistance check',metric:'contact_resistance',unit:'Ω·cm²',rule:'nonnegative',description:'Checks non-negative contact resistance.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
