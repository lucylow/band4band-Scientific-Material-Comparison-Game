import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:310,slug:'effective-mass-anisotropy',title:'Effective-mass anisotropy',metric:'mass_anisotropy',unit:'ratio',rule:'positive',description:'Checks a supplied effective-mass anisotropy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
