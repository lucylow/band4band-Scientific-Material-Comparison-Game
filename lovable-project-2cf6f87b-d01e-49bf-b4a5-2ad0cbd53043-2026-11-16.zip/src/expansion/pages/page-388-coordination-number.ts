import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:388,slug:'coordination-number',title:'Coordination number',metric:'coordination',unit:'count',rule:'positive_integer',description:'Checks a supplied coordination number value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
