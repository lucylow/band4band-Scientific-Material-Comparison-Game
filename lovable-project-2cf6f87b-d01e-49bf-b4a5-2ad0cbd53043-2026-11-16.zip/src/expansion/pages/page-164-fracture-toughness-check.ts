import {evaluateFeature} from '../featureEngine';
export const module={id:164,slug:'fracture-toughness-check',title:'Fracture toughness check',metric:'fracture_toughness',unit:'MPa√m',rule:'positive',description:'Checks positive fracture toughness.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
