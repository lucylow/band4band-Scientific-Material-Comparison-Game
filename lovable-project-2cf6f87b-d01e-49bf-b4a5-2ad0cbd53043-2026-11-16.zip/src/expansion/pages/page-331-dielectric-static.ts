import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:331,slug:'dielectric-static',title:'Static dielectric constant',metric:'dielectric_static',unit:'dimensionless',rule:'positive',description:'Checks a supplied static dielectric constant value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
