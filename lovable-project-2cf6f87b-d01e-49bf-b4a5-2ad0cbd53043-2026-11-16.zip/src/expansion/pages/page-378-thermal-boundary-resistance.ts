import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:378,slug:'thermal-boundary-resistance',title:'Thermal boundary resistance',metric:'thermal_boundary',unit:'m²K/W',rule:'nonnegative',description:'Checks a supplied thermal boundary resistance value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
