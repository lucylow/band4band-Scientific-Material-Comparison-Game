import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:425,slug:'provenance-author-present',title:'Provenance Author Present',metric:'provenance_author_present',unit:'—',rule:'fraction',description:'Checks provenance author present for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
