import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:341,slug:'defect-formation-energy',title:'Defect formation energy',metric:'defect_formation',unit:'eV',rule:'signed',description:'Checks a supplied defect formation energy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
