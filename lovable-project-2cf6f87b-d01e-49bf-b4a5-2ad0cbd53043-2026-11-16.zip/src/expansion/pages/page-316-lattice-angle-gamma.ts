import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:316,slug:'lattice-angle-gamma',title:'Lattice angle gamma',metric:'gamma',unit:'degrees',rule:'angle',description:'Checks a supplied lattice angle gamma value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
