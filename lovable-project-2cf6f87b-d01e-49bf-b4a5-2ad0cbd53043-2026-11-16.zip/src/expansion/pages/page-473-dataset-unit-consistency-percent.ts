import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:473,slug:'dataset-unit-consistency-percent',title:'Dataset Unit Consistency Percent',metric:'dataset_unit_consistency_percent',unit:'—',rule:'percent',description:'Checks dataset unit consistency percent for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
