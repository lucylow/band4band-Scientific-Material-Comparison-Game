import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:266,slug:'friction-coefficient',title:'Friction coefficient',metric:'friction',unit:'dimensionless',rule:'nonnegative',description:'Screens friction coefficient values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
