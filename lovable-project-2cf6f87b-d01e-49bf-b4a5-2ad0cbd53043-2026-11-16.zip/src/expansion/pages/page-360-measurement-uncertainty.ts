import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:360,slug:'measurement-uncertainty',title:'Measurement uncertainty',metric:'measurement_uncertainty',unit:'%',rule:'percent',description:'Checks a supplied measurement uncertainty value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
