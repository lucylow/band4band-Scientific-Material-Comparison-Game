import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:265,slug:'wear-rate',title:'Wear rate',metric:'wear_rate',unit:'mm³/(N·m)',rule:'nonnegative',description:'Screens wear rate values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
