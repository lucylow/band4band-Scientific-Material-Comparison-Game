import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:457,slug:'validation-reduced-chi-squared',title:'Validation Reduced Chi Squared',metric:'validation_reduced_chi_squared',unit:'—',rule:'nonnegative',description:'Checks validation reduced chi squared for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
