import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:395,slug:'citation-count',title:'Citation count',metric:'citation_count',unit:'citations',rule:'nonnegative',description:'Checks a supplied citation count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
