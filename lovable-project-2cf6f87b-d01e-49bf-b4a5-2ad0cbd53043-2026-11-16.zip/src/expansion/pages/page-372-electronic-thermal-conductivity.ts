import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:372,slug:'electronic-thermal-conductivity',title:'Electronic thermal conductivity',metric:'kappa_electronic',unit:'W/m·K',rule:'nonnegative',description:'Checks a supplied electronic thermal conductivity value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
