import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:410,slug:'uncertainty-interval-width',title:'Uncertainty Interval Width',metric:'uncertainty_interval_width',unit:'—',rule:'nonnegative',description:'Checks uncertainty interval width for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
