import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:476,slug:'dataset-pressure-coverage',title:'Dataset Pressure Coverage',metric:'dataset_pressure_coverage',unit:'—',rule:'nonnegative',description:'Checks dataset pressure coverage for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
