import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:474,slug:'dataset-phase-consistency-percent',title:'Dataset Phase Consistency Percent',metric:'dataset_phase_consistency_percent',unit:'—',rule:'percent',description:'Checks dataset phase consistency percent for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
