import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:446,slug:'experimental-instrument-resolution',title:'Experimental Instrument Resolution',metric:'experimental_instrument_resolution',unit:'—',rule:'positive',description:'Checks experimental instrument resolution for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
