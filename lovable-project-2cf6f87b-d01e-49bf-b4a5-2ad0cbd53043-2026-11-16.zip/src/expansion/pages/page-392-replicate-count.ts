import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:392,slug:'replicate-count',title:'Replicate count',metric:'replicate_count',unit:'samples',rule:'positive_integer',description:'Checks a supplied replicate count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
