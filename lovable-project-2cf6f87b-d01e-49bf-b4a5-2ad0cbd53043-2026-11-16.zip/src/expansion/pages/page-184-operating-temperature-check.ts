import {evaluateFeature} from '../featureEngine';
export const module={id:184,slug:'operating-temperature-check',title:'Operating temperature check',metric:'operating_temperature',unit:'K',rule:'positive',description:'Checks positive absolute operating temperature.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
