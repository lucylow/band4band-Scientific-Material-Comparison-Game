import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:349,slug:'surface-energy',title:'Surface energy',metric:'surface_energy',unit:'J/m²',rule:'nonnegative',description:'Checks a supplied surface energy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
