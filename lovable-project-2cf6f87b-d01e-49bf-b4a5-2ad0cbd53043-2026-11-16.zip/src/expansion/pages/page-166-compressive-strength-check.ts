import {evaluateFeature} from '../featureEngine';
export const module={id:166,slug:'compressive-strength-check',title:'Compressive strength check',metric:'compressive_strength',unit:'MPa',rule:'positive',description:'Checks positive compressive strength.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
