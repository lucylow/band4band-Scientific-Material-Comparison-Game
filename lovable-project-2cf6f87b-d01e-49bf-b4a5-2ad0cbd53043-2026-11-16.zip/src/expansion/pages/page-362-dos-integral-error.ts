import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:362,slug:'dos-integral-error',title:'DOS integral discrepancy',metric:'dos_integral_error',unit:'%',rule:'percent',description:'Checks a supplied dos integral discrepancy value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
