import {evaluateFeature} from '../featureEngine';
export const module={id:117,slug:'dielectric-constant-check',title:'Dielectric constant check',metric:'dielectric_constant',unit:'1',rule:'positive',description:'Validates positive dielectric response.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
