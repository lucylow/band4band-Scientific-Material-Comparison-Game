import {evaluateFeature} from '../featureEngine';
export const module={id:189,slug:'supply-risk-check',title:'Supply risk check',metric:'supply_risk',unit:'score',rule:'range',description:'Checks supply-risk score in the configured range.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
