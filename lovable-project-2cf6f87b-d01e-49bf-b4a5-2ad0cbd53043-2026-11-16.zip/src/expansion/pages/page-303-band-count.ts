import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:303,slug:'band-count',title:'Band count',metric:'band_count',unit:'bands',rule:'positive_integer',description:'Checks a supplied band count value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
