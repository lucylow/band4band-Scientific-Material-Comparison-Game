import {evaluateFeature} from '../featureEngine';
export const module={id:129,slug:'lattice-angle-alpha',title:'Lattice alpha check',metric:'alpha',unit:'degree',rule:'angle',description:'Checks crystallographic angle alpha.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
