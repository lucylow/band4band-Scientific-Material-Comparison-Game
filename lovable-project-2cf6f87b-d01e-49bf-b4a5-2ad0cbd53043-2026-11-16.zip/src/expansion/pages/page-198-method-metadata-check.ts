import {evaluateFeature} from '../featureEngine';
export const module={id:198,slug:'method-metadata-check',title:'Method metadata',metric:'method_present',unit:'boolean',rule:'boolean',description:'Requires a method label for computational evidence.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
