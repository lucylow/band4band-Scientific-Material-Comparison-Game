import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:268,slug:'surface-tension',title:'Surface tension',metric:'surface_tension',unit:'N/m',rule:'nonnegative',description:'Screens surface tension values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
