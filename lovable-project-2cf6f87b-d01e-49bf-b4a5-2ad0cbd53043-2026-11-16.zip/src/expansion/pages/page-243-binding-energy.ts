import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:243,slug:'binding-energy',title:'Binding energy',metric:'binding_energy',unit:'eV',rule:'signed',description:'Screens binding energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
