import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:240,slug:'grain-boundary-energy',title:'Grain-boundary energy',metric:'gb_energy',unit:'J/m²',rule:'nonnegative',description:'Screens grain-boundary energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
