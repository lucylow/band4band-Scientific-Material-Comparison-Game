import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:400,slug:'confidence-interval-width',title:'Confidence interval width',metric:'ci_width',unit:'eV',rule:'nonnegative',description:'Checks a supplied confidence interval width value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
