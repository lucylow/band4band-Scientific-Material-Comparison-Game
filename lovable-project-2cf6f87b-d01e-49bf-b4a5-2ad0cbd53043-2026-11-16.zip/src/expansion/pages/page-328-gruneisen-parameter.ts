import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:328,slug:'gruneisen-parameter',title:'Gruneisen parameter',metric:'gruneisen',unit:'dimensionless',rule:'signed',description:'Checks a supplied gruneisen parameter value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
