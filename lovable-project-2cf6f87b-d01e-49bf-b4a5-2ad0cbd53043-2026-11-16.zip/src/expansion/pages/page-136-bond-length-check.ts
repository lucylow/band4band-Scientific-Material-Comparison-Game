import {evaluateFeature} from '../featureEngine';
export const module={id:136,slug:'bond-length-check',title:'Bond length check',metric:'bond_length',unit:'Å',rule:'positive',description:'Checks positive bond length.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
