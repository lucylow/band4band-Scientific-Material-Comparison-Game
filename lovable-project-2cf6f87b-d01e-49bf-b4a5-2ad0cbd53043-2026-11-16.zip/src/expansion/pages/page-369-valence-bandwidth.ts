import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:369,slug:'valence-bandwidth',title:'Valence bandwidth',metric:'valence_bandwidth',unit:'eV',rule:'nonnegative',description:'Checks a supplied valence bandwidth value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
