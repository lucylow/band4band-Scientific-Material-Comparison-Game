import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:417,slug:'replicate-count-effective',title:'Replicate Count Effective',metric:'replicate_count_effective',unit:'—',rule:'positive_integer',description:'Checks replicate count effective for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
