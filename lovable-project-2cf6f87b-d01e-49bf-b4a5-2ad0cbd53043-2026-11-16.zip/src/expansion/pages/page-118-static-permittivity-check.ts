import {evaluateFeature} from '../featureEngine';
export const module={id:118,slug:'static-permittivity-check',title:'Static permittivity check',metric:'static_permittivity',unit:'1',rule:'positive',description:'Validates static permittivity values.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
