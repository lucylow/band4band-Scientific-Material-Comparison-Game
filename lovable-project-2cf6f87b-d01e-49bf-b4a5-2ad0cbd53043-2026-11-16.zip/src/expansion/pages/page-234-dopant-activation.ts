import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:234,slug:'dopant-activation',title:'Dopant activation fraction',metric:'dopant_activation',unit:'%',rule:'percent',description:'Screens dopant activation fraction values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
