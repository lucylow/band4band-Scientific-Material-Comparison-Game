import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:343,slug:'defect-concentration',title:'Defect concentration',metric:'defect_concentration',unit:'cm⁻³',rule:'nonnegative',description:'Checks a supplied defect concentration value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
