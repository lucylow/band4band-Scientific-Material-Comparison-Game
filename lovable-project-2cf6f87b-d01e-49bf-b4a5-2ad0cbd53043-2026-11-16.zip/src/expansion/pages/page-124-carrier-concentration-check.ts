import {evaluateFeature} from '../featureEngine';
export const module={id:124,slug:'carrier-concentration-check',title:'Carrier concentration check',metric:'carrier_concentration',unit:'cm⁻³',rule:'positive',description:'Validates positive carrier concentration.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
