import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:267,slug:'contact-angle',title:'Wetting contact angle',metric:'contact_angle',unit:'degrees',rule:'angle',description:'Screens wetting contact angle values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
