import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:226,slug:'vacancy-formation-energy',title:'Vacancy formation energy',metric:'vacancy_formation',unit:'eV',rule:'signed',description:'Screens vacancy formation energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
