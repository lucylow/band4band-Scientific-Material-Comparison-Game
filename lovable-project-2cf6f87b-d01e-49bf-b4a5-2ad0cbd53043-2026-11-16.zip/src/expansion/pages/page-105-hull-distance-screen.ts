import {evaluateFeature} from '../featureEngine';
export const module={id:105,slug:'hull-distance-screen',title:'Energy above hull screen',metric:'energy_above_hull',unit:'eV/atom',rule:'lower',description:'Screens phase stability proxy values without declaring synthesizability.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
