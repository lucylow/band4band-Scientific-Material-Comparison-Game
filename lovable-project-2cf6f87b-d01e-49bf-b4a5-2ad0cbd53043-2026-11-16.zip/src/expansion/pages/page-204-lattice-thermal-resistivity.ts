import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:204,slug:'lattice-thermal-resistivity',title:'Lattice thermal resistivity',metric:'thermal_resistivity',unit:'m·K/W',rule:'positive',description:'Screens lattice thermal resistivity values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
