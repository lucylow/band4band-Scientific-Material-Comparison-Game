import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:482,slug:'reproducibility-code-commit-present',title:'Reproducibility Code Commit Present',metric:'reproducibility_code_commit_present',unit:'—',rule:'fraction',description:'Checks reproducibility code commit present for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
