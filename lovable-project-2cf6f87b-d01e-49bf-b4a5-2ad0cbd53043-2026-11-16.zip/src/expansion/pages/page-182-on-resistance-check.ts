import {evaluateFeature} from '../featureEngine';
export const module={id:182,slug:'on-resistance-check',title:'On resistance check',metric:'on_resistance',unit:'Ω',rule:'positive',description:'Checks positive on-state resistance.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
