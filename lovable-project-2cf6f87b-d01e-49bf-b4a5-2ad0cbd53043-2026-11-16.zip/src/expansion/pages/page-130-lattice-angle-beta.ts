import {evaluateFeature} from '../featureEngine';
export const module={id:130,slug:'lattice-angle-beta',title:'Lattice beta check',metric:'beta',unit:'degree',rule:'angle',description:'Checks crystallographic angle beta.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
