import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:499,slug:'sensitivity-monotonicity-score',title:'Sensitivity Monotonicity Score',metric:'sensitivity_monotonicity_score',unit:'—',rule:'fraction',description:'Checks sensitivity monotonicity score for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
