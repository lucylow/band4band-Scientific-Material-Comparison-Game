import {evaluateFeature} from '../featureEngine';
export const module={id:139,slug:'surface-area-check',title:'Surface area check',metric:'surface_area',unit:'m²/g',rule:'nonnegative',description:'Checks non-negative specific surface area.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
