import {evaluateFeature} from '../featureEngine';
export const module={id:149,slug:'seebeck-check',title:'Seebeck coefficient check',metric:'seebeck',unit:'μV/K',rule:'finite',description:'Checks finite Seebeck coefficient.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
