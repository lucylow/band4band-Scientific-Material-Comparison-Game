import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:355,slug:'force-residual',title:'Force residual',metric:'force_residual',unit:'eV/Å',rule:'nonnegative',description:'Checks a supplied force residual value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
