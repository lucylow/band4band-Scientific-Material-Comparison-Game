import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:231,slug:'defect-charge-state',title:'Defect charge state',metric:'defect_charge',unit:'e',rule:'signed',description:'Screens defect charge state values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
