import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:346,slug:'migration-barrier',title:'Migration barrier',metric:'migration_barrier',unit:'eV',rule:'nonnegative',description:'Checks a supplied migration barrier value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
