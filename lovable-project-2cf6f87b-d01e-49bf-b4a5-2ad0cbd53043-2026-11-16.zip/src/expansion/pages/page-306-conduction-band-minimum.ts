import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:306,slug:'conduction-band-minimum',title:'Conduction band minimum',metric:'cbm',unit:'eV',rule:'signed',description:'Checks a supplied conduction band minimum value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
