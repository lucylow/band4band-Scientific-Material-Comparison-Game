import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:429,slug:'provenance-version-present',title:'Provenance Version Present',metric:'provenance_version_present',unit:'—',rule:'fraction',description:'Checks provenance version present for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
