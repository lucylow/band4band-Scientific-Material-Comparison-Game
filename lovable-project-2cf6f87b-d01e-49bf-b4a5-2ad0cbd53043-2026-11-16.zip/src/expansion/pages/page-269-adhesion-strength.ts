import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:269,slug:'adhesion-strength',title:'Adhesion strength',metric:'adhesion_strength',unit:'MPa',rule:'nonnegative',description:'Screens adhesion strength values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
