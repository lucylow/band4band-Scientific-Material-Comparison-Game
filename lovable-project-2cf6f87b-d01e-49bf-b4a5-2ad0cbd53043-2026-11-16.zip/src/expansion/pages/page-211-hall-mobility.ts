import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:211,slug:'hall-mobility',title:'Hall mobility',metric:'hall_mobility',unit:'m²/(V·s)',rule:'nonnegative',description:'Screens hall mobility values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
