import {evaluateFeature} from '../featureEngine';
export const module={id:135,slug:'coordination-number-check',title:'Coordination number check',metric:'coordination_number',unit:'count',rule:'integer',description:'Checks non-negative coordination number.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
