import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:451,slug:'validation-absolute-deviation',title:'Validation Absolute Deviation',metric:'validation_absolute_deviation',unit:'—',rule:'nonnegative',description:'Checks validation absolute deviation for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
