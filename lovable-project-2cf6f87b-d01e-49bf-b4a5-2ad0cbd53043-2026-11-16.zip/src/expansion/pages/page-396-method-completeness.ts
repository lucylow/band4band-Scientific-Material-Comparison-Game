import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:396,slug:'method-completeness',title:'Method metadata completeness',metric:'method_completeness',unit:'%',rule:'percent',description:'Checks a supplied method metadata completeness value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
