import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:241,slug:'surface-reconstruction-energy',title:'Surface reconstruction energy',metric:'surface_reconstruction',unit:'eV',rule:'signed',description:'Screens surface reconstruction energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
