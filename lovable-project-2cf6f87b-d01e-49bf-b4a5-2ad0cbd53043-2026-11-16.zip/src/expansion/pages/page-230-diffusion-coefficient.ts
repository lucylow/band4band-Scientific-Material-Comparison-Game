import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:230,slug:'diffusion-coefficient',title:'Diffusion coefficient',metric:'diffusion_coefficient',unit:'m²/s',rule:'nonnegative',description:'Screens diffusion coefficient values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
