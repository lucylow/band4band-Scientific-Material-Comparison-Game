import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:207,slug:'power-factor',title:'Thermoelectric power factor',metric:'power_factor',unit:'W/(m·K²)',rule:'nonnegative',description:'Screens thermoelectric power factor values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
