import {evaluateFeature} from '../featureEngine';
export const module={id:175,slug:'purity-check',title:'Purity check',metric:'purity',unit:'%',rule:'percent',description:'Checks purity percentage range.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
