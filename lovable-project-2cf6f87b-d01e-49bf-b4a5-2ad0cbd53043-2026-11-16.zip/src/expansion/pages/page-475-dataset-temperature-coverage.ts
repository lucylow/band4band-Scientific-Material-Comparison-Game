import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:475,slug:'dataset-temperature-coverage',title:'Dataset Temperature Coverage',metric:'dataset_temperature_coverage',unit:'—',rule:'nonnegative',description:'Checks dataset temperature coverage for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
