import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:393,slug:'replica-gap-spread',title:'Replica band-gap spread',metric:'replica_gap_spread',unit:'eV',rule:'nonnegative',description:'Checks a supplied replica band-gap spread value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
