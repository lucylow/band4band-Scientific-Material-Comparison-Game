import {evaluateFeature} from '../featureEngine';
export const module={id:114,slug:'poisson-ratio-check',title:'Poisson ratio check',metric:'poisson_ratio',unit:'1',rule:'poisson',description:'Checks a physically plausible isotropic Poisson ratio interval.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
