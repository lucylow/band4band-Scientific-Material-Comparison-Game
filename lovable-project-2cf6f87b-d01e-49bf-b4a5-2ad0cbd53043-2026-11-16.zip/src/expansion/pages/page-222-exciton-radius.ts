import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:222,slug:'exciton-radius',title:'Exciton Bohr radius',metric:'exciton_radius',unit:'nm',rule:'positive',description:'Screens exciton bohr radius values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
