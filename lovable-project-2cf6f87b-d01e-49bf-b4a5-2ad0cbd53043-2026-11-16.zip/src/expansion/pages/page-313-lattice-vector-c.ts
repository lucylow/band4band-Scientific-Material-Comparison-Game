import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:313,slug:'lattice-vector-c',title:'Lattice vector c length',metric:'lattice_c',unit:'Å',rule:'positive',description:'Checks a supplied lattice vector c length value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
