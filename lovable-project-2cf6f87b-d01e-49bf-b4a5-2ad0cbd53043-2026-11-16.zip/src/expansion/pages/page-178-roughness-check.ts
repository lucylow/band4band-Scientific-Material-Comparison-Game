import {evaluateFeature} from '../featureEngine';
export const module={id:178,slug:'roughness-check',title:'Surface roughness check',metric:'roughness',unit:'nm',rule:'nonnegative',description:'Checks non-negative surface roughness.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
