import {evaluateFeature} from '../featureEngine';
export const module={id:104,slug:'formation-energy-screen',title:'Formation energy screen',metric:'formation_energy',unit:'eV/atom',rule:'lower',description:'Ranks only comparable formation-energy records.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
