import {evaluateFeature} from '../featureEngine';
export const module={id:115,slug:'hardness-screen',title:'Hardness screen',metric:'hardness',unit:'GPa',rule:'positive',description:'Validates positive hardness measurements.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
