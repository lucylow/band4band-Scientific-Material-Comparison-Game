import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:398,slug:'unit-conversion-residual',title:'Unit conversion residual',metric:'unit_residual',unit:'%',rule:'nonnegative',description:'Checks a supplied unit conversion residual value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
