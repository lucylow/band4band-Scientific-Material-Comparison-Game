import {evaluateFeature} from '../featureEngine';
export const module={id:199,slug:'evidence-coverage-check',title:'Evidence coverage',metric:'evidence_coverage',unit:'%',rule:'percent',description:'Checks evidence coverage percentage.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
