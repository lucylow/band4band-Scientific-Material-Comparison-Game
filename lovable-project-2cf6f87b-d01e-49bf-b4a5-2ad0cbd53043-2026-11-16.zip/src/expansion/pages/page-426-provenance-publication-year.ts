import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:426,slug:'provenance-publication-year',title:'Provenance Publication Year',metric:'provenance_publication_year',unit:'—',rule:'positive_integer',description:'Checks provenance publication year for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
