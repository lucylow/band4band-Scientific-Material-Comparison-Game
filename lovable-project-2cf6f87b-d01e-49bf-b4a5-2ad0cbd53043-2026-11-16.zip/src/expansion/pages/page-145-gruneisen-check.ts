import {evaluateFeature} from '../featureEngine';
export const module={id:145,slug:'gruneisen-check',title:'Gruneisen parameter check',metric:'gruneisen_parameter',unit:'1',rule:'finite',description:'Checks finite Gruneisen parameter.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
