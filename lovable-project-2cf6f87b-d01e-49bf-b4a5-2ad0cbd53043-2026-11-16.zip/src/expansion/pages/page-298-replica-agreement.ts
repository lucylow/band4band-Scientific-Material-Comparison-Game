import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:298,slug:'replica-agreement',title:'Replica agreement',metric:'replica_agreement',unit:'%',rule:'percent',description:'Screens replica agreement values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
