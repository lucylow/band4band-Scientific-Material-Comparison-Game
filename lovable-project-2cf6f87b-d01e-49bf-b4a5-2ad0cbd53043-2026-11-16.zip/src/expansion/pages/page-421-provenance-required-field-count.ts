import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:421,slug:'provenance-required-field-count',title:'Provenance Required Field Count',metric:'provenance_required_field_count',unit:'—',rule:'positive_integer',description:'Checks provenance required field count for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
