import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:403,slug:'uncertainty-relative-percent',title:'Uncertainty Relative Percent',metric:'uncertainty_relative_percent',unit:'—',rule:'percent',description:'Checks uncertainty relative percent for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
