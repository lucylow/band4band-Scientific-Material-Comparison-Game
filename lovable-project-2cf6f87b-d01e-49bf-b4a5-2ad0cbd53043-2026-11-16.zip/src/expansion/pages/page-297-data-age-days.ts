import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:297,slug:'data-age-days',title:'Data age',metric:'data_age',unit:'days',rule:'nonnegative',description:'Screens data age values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
