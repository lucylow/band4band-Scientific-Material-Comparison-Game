import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:275,slug:'switching-frequency',title:'Switching frequency',metric:'switching_frequency',unit:'Hz',rule:'positive',description:'Screens switching frequency values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
