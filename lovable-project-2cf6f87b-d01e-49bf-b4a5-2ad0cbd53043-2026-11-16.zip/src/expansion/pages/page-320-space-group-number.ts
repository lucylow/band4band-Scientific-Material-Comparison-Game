import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:320,slug:'space-group-number',title:'Space-group number',metric:'space_group',unit:'number',rule:'positive_integer',description:'Checks a supplied space-group number value for finite numeric input and a declared physical range. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
