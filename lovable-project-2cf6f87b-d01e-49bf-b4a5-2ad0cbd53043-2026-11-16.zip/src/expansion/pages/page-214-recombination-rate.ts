import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:214,slug:'recombination-rate',title:'Recombination rate',metric:'recombination_rate',unit:'s⁻¹',rule:'nonnegative',description:'Screens recombination rate values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
