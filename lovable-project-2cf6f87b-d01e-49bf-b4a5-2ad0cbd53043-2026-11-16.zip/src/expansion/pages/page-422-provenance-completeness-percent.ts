import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:422,slug:'provenance-completeness-percent',title:'Provenance Completeness Percent',metric:'provenance_completeness_percent',unit:'—',rule:'percent',description:'Checks provenance completeness percent for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
