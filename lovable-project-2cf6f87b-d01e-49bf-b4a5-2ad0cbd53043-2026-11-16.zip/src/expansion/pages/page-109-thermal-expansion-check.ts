import {evaluateFeature} from '../featureEngine';
export const module={id:109,slug:'thermal-expansion-check',title:'Thermal expansion check',metric:'thermal_expansion',unit:'1/K',rule:'finite',description:'Validates finite thermal expansion coefficient.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
