import {evaluateFeature} from '../featureEngine';
export const module={id:170,slug:'corrosion-rate-check',title:'Corrosion rate check',metric:'corrosion_rate',unit:'mm/year',rule:'nonnegative',description:'Checks non-negative corrosion rate.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
