import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:289,slug:'water-footprint',title:'Water footprint',metric:'water_footprint',unit:'L/kg',rule:'nonnegative',description:'Screens water footprint values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
