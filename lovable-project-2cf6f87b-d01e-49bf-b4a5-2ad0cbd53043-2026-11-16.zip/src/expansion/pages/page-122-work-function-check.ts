import {evaluateFeature} from '../featureEngine';
export const module={id:122,slug:'work-function-check',title:'Work function check',metric:'work_function',unit:'eV',rule:'positive',description:'Checks positive work function values.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
