import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:481,slug:'reproducibility-environment-lockfile',title:'Reproducibility Environment Lockfile',metric:'reproducibility_environment_lockfile',unit:'—',rule:'fraction',description:'Checks reproducibility environment lockfile for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
