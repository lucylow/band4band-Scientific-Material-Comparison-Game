import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:288,slug:'embodied-energy',title:'Embodied energy',metric:'embodied_energy',unit:'MJ/kg',rule:'nonnegative',description:'Screens embodied energy values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
