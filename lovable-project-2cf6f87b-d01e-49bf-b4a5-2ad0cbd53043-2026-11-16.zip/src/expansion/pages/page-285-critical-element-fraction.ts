import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:285,slug:'critical-element-fraction',title:'Critical element fraction',metric:'critical_fraction',unit:'%',rule:'percent',description:'Screens critical element fraction values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
