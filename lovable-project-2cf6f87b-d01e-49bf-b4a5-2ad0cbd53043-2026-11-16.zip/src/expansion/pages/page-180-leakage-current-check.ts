import {evaluateFeature} from '../featureEngine';
export const module={id:180,slug:'leakage-current-check',title:'Leakage current check',metric:'leakage_current',unit:'A',rule:'nonnegative',description:'Checks non-negative leakage current.'} as const;
export function evaluate(value:number|boolean|null){return evaluateFeature(module.rule,value);}
