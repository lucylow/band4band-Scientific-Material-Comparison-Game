import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:441,slug:'experimental-temperature',title:'Experimental Temperature',metric:'experimental_temperature',unit:'—',rule:'positive',description:'Checks experimental temperature for finite numeric input and a declared screening rule. This is an input-quality check, not a source or measurement validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
