import {evaluateAdvancedMetric} from '../advancedEngine';
export const module={id:272,slug:'dielectric-loss-tangent',title:'Dielectric loss tangent',metric:'loss_tangent',unit:'dimensionless',rule:'nonnegative',description:'Screens dielectric loss tangent values for missing, non-finite or rule-inconsistent inputs. This is an input-quality check, not a literature validation.'} as const;
export function evaluate(value:number|null){return evaluateAdvancedMetric(module.rule,value);}
