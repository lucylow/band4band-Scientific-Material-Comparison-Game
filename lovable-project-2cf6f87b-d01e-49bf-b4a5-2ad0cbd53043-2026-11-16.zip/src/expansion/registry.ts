import {module as m500, evaluate as e500} from './pages/page-500-sensitivity-stability-index';
import {CRYSTAL_BAND_MODULES} from './pages/registry-301-400';
import {PROVENANCE_QUALITY_MODULES} from './pages/registry-401-500';
import {ADVANCED_MODULES} from './pages/registry-201-300';
import {module as m101,evaluate as e101} from './pages/page-101-bandgap-classifier';
import {module as m102,evaluate as e102} from './pages/page-102-direct-gap-review';
import {module as m103,evaluate as e103} from './pages/page-103-indirect-gap-review';
import {module as m104,evaluate as e104} from './pages/page-104-formation-energy-screen';
import {module as m105,evaluate as e105} from './pages/page-105-hull-distance-screen';
import {module as m106,evaluate as e106} from './pages/page-106-density-window';
import {module as m107,evaluate as e107} from './pages/page-107-thermal-conductivity-window';
import {module as m108,evaluate as e108} from './pages/page-108-specific-heat-check';
import {module as m109,evaluate as e109} from './pages/page-109-thermal-expansion-check';
import {module as m110,evaluate as e110} from './pages/page-110-melting-point-check';
import {module as m111,evaluate as e111} from './pages/page-111-young-modulus-check';
import {module as m112,evaluate as e112} from './pages/page-112-bulk-modulus-check';
import {module as m113,evaluate as e113} from './pages/page-113-shear-modulus-check';
import {module as m114,evaluate as e114} from './pages/page-114-poisson-ratio-check';
import {module as m115,evaluate as e115} from './pages/page-115-hardness-screen';
import {module as m116,evaluate as e116} from './pages/page-116-refractive-index-check';
import {module as m117,evaluate as e117} from './pages/page-117-dielectric-constant-check';
import {module as m118,evaluate as e118} from './pages/page-118-static-permittivity-check';
import {module as m119,evaluate as e119} from './pages/page-119-magnetic-moment-check';
import {module as m120,evaluate as e120} from './pages/page-120-fermi-energy-check';
import {module as m121,evaluate as e121} from './pages/page-121-electron-affinity-check';
import {module as m122,evaluate as e122} from './pages/page-122-work-function-check';
import {module as m123,evaluate as e123} from './pages/page-123-carrier-mobility-check';
import {module as m124,evaluate as e124} from './pages/page-124-carrier-concentration-check';
import {module as m125,evaluate as e125} from './pages/page-125-breakdown-field-check';
import {module as m126,evaluate as e126} from './pages/page-126-lattice-a-check';
import {module as m127,evaluate as e127} from './pages/page-127-lattice-b-check';
import {module as m128,evaluate as e128} from './pages/page-128-lattice-c-check';
import {module as m129,evaluate as e129} from './pages/page-129-lattice-angle-alpha';
import {module as m130,evaluate as e130} from './pages/page-130-lattice-angle-beta';
import {module as m131,evaluate as e131} from './pages/page-131-lattice-angle-gamma';
import {module as m132,evaluate as e132} from './pages/page-132-unit-cell-volume-check';
import {module as m133,evaluate as e133} from './pages/page-133-site-count-check';
import {module as m134,evaluate as e134} from './pages/page-134-space-group-check';
import {module as m135,evaluate as e135} from './pages/page-135-coordination-number-check';
import {module as m136,evaluate as e136} from './pages/page-136-bond-length-check';
import {module as m137,evaluate as e137} from './pages/page-137-bond-angle-check';
import {module as m138,evaluate as e138} from './pages/page-138-porosity-check';
import {module as m139,evaluate as e139} from './pages/page-139-surface-area-check';
import {module as m140,evaluate as e140} from './pages/page-140-bandwidth-check';
import {module as m141,evaluate as e141} from './pages/page-141-dos-at-fermi-check';
import {module as m142,evaluate as e142} from './pages/page-142-effective-mass-check';
import {module as m143,evaluate as e143} from './pages/page-143-phonon-frequency-check';
import {module as m144,evaluate as e144} from './pages/page-144-debye-temperature-check';
import {module as m145,evaluate as e145} from './pages/page-145-gruneisen-check';
import {module as m146,evaluate as e146} from './pages/page-146-thermal-diffusivity-check';
import {module as m147,evaluate as e147} from './pages/page-147-electrical-resistivity-check';
import {module as m148,evaluate as e148} from './pages/page-148-electrical-conductivity-check';
import {module as m149,evaluate as e149} from './pages/page-149-seebeck-check';
import {module as m150,evaluate as e150} from './pages/page-150-zT-check';
import {module as m151,evaluate as e151} from './pages/page-151-solar-absorption-check';
import {module as m152,evaluate as e152} from './pages/page-152-emission-wavelength-check';
import {module as m153,evaluate as e153} from './pages/page-153-band-edge-check';
import {module as m154,evaluate as e154} from './pages/page-154-exciton-binding-check';
import {module as m155,evaluate as e155} from './pages/page-155-defect-formation-check';
import {module as m156,evaluate as e156} from './pages/page-156-vacancy-concentration-check';
import {module as m157,evaluate as e157} from './pages/page-157-dopant-concentration-check';
import {module as m158,evaluate as e158} from './pages/page-158-dopant-activation-check';
import {module as m159,evaluate as e159} from './pages/page-159-diffusion-barrier-check';
import {module as m160,evaluate as e160} from './pages/page-160-interface-energy-check';
import {module as m161,evaluate as e161} from './pages/page-161-surface-energy-check';
import {module as m162,evaluate as e162} from './pages/page-162-adhesion-energy-check';
import {module as m163,evaluate as e163} from './pages/page-163-elastic-anisotropy-check';
import {module as m164,evaluate as e164} from './pages/page-164-fracture-toughness-check';
import {module as m165,evaluate as e165} from './pages/page-165-tensile-strength-check';
import {module as m166,evaluate as e166} from './pages/page-166-compressive-strength-check';
import {module as m167,evaluate as e167} from './pages/page-167-fatigue-limit-check';
import {module as m168,evaluate as e168} from './pages/page-168-creep-rate-check';
import {module as m169,evaluate as e169} from './pages/page-169-oxidation-rate-check';
import {module as m170,evaluate as e170} from './pages/page-170-corrosion-rate-check';
import {module as m171,evaluate as e171} from './pages/page-171-chemical-stability-check';
import {module as m172,evaluate as e172} from './pages/page-172-phase-fraction-check';
import {module as m173,evaluate as e173} from './pages/page-173-composition-sum-check';
import {module as m174,evaluate as e174} from './pages/page-174-stoichiometry-check';
import {module as m175,evaluate as e175} from './pages/page-175-purity-check';
import {module as m176,evaluate as e176} from './pages/page-176-grain-size-check';
import {module as m177,evaluate as e177} from './pages/page-177-dislocation-density-check';
import {module as m178,evaluate as e178} from './pages/page-178-roughness-check';
import {module as m179,evaluate as e179} from './pages/page-179-contact-resistance-check';
import {module as m180,evaluate as e180} from './pages/page-180-leakage-current-check';
import {module as m181,evaluate as e181} from './pages/page-181-switching-loss-check';
import {module as m182,evaluate as e182} from './pages/page-182-on-resistance-check';
import {module as m183,evaluate as e183} from './pages/page-183-device-efficiency-check';
import {module as m184,evaluate as e184} from './pages/page-184-operating-temperature-check';
import {module as m185,evaluate as e185} from './pages/page-185-thermal-cycling-check';
import {module as m186,evaluate as e186} from './pages/page-186-radiation-dose-check';
import {module as m187,evaluate as e187} from './pages/page-187-neutron-fluence-check';
import {module as m188,evaluate as e188} from './pages/page-188-cost-per-kg-check';
import {module as m189,evaluate as e189} from './pages/page-189-supply-risk-check';
import {module as m190,evaluate as e190} from './pages/page-190-embodied-carbon-check';
import {module as m191,evaluate as e191} from './pages/page-191-recyclability-check';
import {module as m192,evaluate as e192} from './pages/page-192-criticality-check';
import {module as m193,evaluate as e193} from './pages/page-193-measurement-temperature-check';
import {module as m194,evaluate as e194} from './pages/page-194-uncertainty-check';
import {module as m195,evaluate as e195} from './pages/page-195-replicate-count-check';
import {module as m196,evaluate as e196} from './pages/page-196-source-date-check';
import {module as m197,evaluate as e197} from './pages/page-197-citation-check';
import {module as m198,evaluate as e198} from './pages/page-198-method-metadata-check';
import {module as m199,evaluate as e199} from './pages/page-199-evidence-coverage-check';
import {module as m200,evaluate as e200} from './pages/page-200-data-freshness-check';
export const FEATURE_MODULES=[
{...m101,evaluate:e101},
{...m102,evaluate:e102},
{...m103,evaluate:e103},
{...m104,evaluate:e104},
{...m105,evaluate:e105},
{...m106,evaluate:e106},
{...m107,evaluate:e107},
{...m108,evaluate:e108},
{...m109,evaluate:e109},
{...m110,evaluate:e110},
{...m111,evaluate:e111},
{...m112,evaluate:e112},
{...m113,evaluate:e113},
{...m114,evaluate:e114},
{...m115,evaluate:e115},
{...m116,evaluate:e116},
{...m117,evaluate:e117},
{...m118,evaluate:e118},
{...m119,evaluate:e119},
{...m120,evaluate:e120},
{...m121,evaluate:e121},
{...m122,evaluate:e122},
{...m123,evaluate:e123},
{...m124,evaluate:e124},
{...m125,evaluate:e125},
{...m126,evaluate:e126},
{...m127,evaluate:e127},
{...m128,evaluate:e128},
{...m129,evaluate:e129},
{...m130,evaluate:e130},
{...m131,evaluate:e131},
{...m132,evaluate:e132},
{...m133,evaluate:e133},
{...m134,evaluate:e134},
{...m135,evaluate:e135},
{...m136,evaluate:e136},
{...m137,evaluate:e137},
{...m138,evaluate:e138},
{...m139,evaluate:e139},
{...m140,evaluate:e140},
{...m141,evaluate:e141},
{...m142,evaluate:e142},
{...m143,evaluate:e143},
{...m144,evaluate:e144},
{...m145,evaluate:e145},
{...m146,evaluate:e146},
{...m147,evaluate:e147},
{...m148,evaluate:e148},
{...m149,evaluate:e149},
{...m150,evaluate:e150},
{...m151,evaluate:e151},
{...m152,evaluate:e152},
{...m153,evaluate:e153},
{...m154,evaluate:e154},
{...m155,evaluate:e155},
{...m156,evaluate:e156},
{...m157,evaluate:e157},
{...m158,evaluate:e158},
{...m159,evaluate:e159},
{...m160,evaluate:e160},
{...m161,evaluate:e161},
{...m162,evaluate:e162},
{...m163,evaluate:e163},
{...m164,evaluate:e164},
{...m165,evaluate:e165},
{...m166,evaluate:e166},
{...m167,evaluate:e167},
{...m168,evaluate:e168},
{...m169,evaluate:e169},
{...m170,evaluate:e170},
{...m171,evaluate:e171},
{...m172,evaluate:e172},
{...m173,evaluate:e173},
{...m174,evaluate:e174},
{...m175,evaluate:e175},
{...m176,evaluate:e176},
{...m177,evaluate:e177},
{...m178,evaluate:e178},
{...m179,evaluate:e179},
{...m180,evaluate:e180},
{...m181,evaluate:e181},
{...m182,evaluate:e182},
{...m183,evaluate:e183},
{...m184,evaluate:e184},
{...m185,evaluate:e185},
{...m186,evaluate:e186},
{...m187,evaluate:e187},
{...m188,evaluate:e188},
{...m189,evaluate:e189},
{...m190,evaluate:e190},
{...m191,evaluate:e191},
{...m192,evaluate:e192},
{...m193,evaluate:e193},
{...m194,evaluate:e194},
{...m195,evaluate:e195},
{...m196,evaluate:e196},
{...m197,evaluate:e197},
{...m198,evaluate:e198},
{...m199,evaluate:e199},
{...m200,evaluate:e200},
...ADVANCED_MODULES,
...CRYSTAL_BAND_MODULES.map(module => ({...module, evaluate: (value: number | boolean | null) => module.evaluate(typeof value === "number" ? value : null)})),
...PROVENANCE_QUALITY_MODULES,
{...m500, evaluate: (value: number | boolean | null) => e500(typeof value === "number" ? value : null)}
] as const;
