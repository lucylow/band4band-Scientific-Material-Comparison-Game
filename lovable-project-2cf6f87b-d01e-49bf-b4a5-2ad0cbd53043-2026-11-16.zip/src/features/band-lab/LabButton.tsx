import { Button, type ButtonProps } from "@/components/ui/button";
export function LabButton(props: ButtonProps) { return <Button variant="lab" size="lab" {...props} />; }
