import type {Material} from '../../data/materials';
import {auditEvidence} from '../../lib/expansion/provenance';
export function PropertyAudit({material}:{material:Material}){const audits=material.properties.map(p=>({p,a:auditEvidence(p)}));return <div className="exp-audit-list">{audits.map(({p,a})=><div key={p.key}><span>{p.label}</span><b className={a.complete?'audit-ok':'audit-warn'}>{a.complete?'Evidence fields present':a.issues.join(' · ')}</b></div>)}</div>;}
